"""Two-level same-covariance experiment with reoptimized response functions.

All computations are floating-point checks of an analytic theorem, not interval
proofs. A law on R is realized by uniformly selecting one coordinate per block
and independent signs, so every probe has at most two nonzero coordinates.
"""
from pathlib import Path
import argparse
import json
import time
import itertools
import numpy as np
from scipy.optimize import brentq, minimize_scalar

HERE=Path(__file__).resolve().parent


def linear_optimum(m,n,a,b,q):
    h=np.r_[np.full(m,a),np.full(n,b)]
    hs=h/h.sum()
    scaled=brentq(lambda t:np.sum((t*hs+np.sqrt(t*t*hs*hs+4*q*t*hs))/2)-1,
                  0.,1.,xtol=1e-14)
    t=scaled/h.sum()
    z=(t*h+np.sqrt(t*t*h*h+4*q*t*h))/2
    amp=z/(z+2*q);amp/=amp.sum()
    return dict(value=float(t),prior=z.tolist(),rstar=float(amp[:m].sum()))


def fraction_terms(gamma,R,m,n,a,b,q):
    zh,zl=gamma/m,(1-gamma)/n
    Nh=R/(m*m*a);Nl=(1-R)/(n*n*b)
    N=Nh*gamma*gamma+Nl*(1-gamma)**2
    Nd=2*Nh*gamma-2*Nl*(1-gamma)
    Ndd=2*(Nh+Nl)
    D=q+R*zh+(1-R)*zl
    Dd=R/m-(1-R)/n
    value=N/D
    deriv=Nd/D-N*Dd/(D*D)
    second=Ndd/D-2*Nd*Dd/(D*D)+2*N*Dd*Dd/(D**3)
    return value,deriv,second


def decoder_gain(R,p,m,n,a,b,q,zh,zl,fixed_denominator=None):
    D=q+R*zh+(1-R)*zl if fixed_denominator is None else np.full_like(R,fixed_denominator)
    kh=zh/(a*D);kl=zl/(b*D)
    noise=a*kh*kh*R+b*kl*kl*(1-R)
    high=float(p@((2*kh-noise)*R/m)-q*(p@noise))
    low=float(p@((2*kl-noise)*(1-R)/n)-q*(p@noise))
    return dict(high_gain=high,low_gain=low,lower=min(high,low),
                coefficient_high=kh.tolist(),coefficient_low=kl.tolist(),
                noise_penalty=float(p@noise))


def fixed_design(R,p,m,n,a,b,q):
    R=np.asarray(R,float);p=np.asarray(p,float)
    value=lambda g:float(p@fraction_terms(g,R,m,n,a,b,q)[0])
    derivative=lambda g:float(p@fraction_terms(g,R,m,n,a,b,q)[1])
    # Bounded convex minimization is independently checked by the analytic
    # derivative, both endpoints, and an interior derivative root when present.
    bounded=minimize_scalar(value,bounds=(0.,1.),method='bounded',
                            options={'xatol':2e-13,'maxiter':500})
    d0,d1=derivative(0.),derivative(1.)
    if d0>=0: gamma=0.
    elif d1<=0: gamma=1.
    else: gamma=brentq(derivative,0.,1.,xtol=5e-15)
    candidates=[(value(0.),0.),(value(1.),1.),(value(gamma),gamma)]
    dual,gamma=min(candidates)
    zh,zl=gamma/m,(1-gamma)/n
    primal=decoder_gain(R,p,m,n,a,b,q,zh,zl)
    return dict(value=dual,gamma=gamma,zh=zh,zl=zl,decoder=primal,
                primal_dual_gap=dual-primal['lower'],bounded_value=float(bounded.fun),
                bounded_difference=float(bounded.fun-dual),bounded_success=bool(bounded.success),
                endpoint_derivatives=[d0,d1],optimum_derivative=derivative(gamma),
                second_derivative=float(p@fraction_terms(gamma,R,m,n,a,b,q)[2]))


def finite_probe_audit(R,p,m,n,a,b,q,task):
    """Explicit sign/coordinate enumeration, independent of block formulas."""
    d=m+n;H=np.diag(np.r_[np.full(m,a),np.full(n,b)])
    covariance=np.zeros((d,d));B=np.zeros((d,d));N=0.
    for rr,pp in zip(R,p):
        D=q+rr*task['zh']+(1-rr)*task['zl']
        scale=np.r_[np.full(m,task['zh']/a/D),np.full(n,task['zl']/b/D)]
        for hi in range(m):
            for li in range(n):
                for sh in [-1.,1.]:
                    for sl in [-1.,1.]:
                        u=np.zeros(d);u[hi]=sh*np.sqrt(rr);u[m+li]=sl*np.sqrt(1-rr)
                        response=scale*u;weight=pp/(4*m*n)
                        nn=response@H@response
                        covariance+=weight*np.outer(u,u)
                        B+=weight*(np.outer(u,response)+np.outer(response,u)-nn*np.outer(u,u))
                        N+=weight*nn
    mean=float(np.asarray(p)@np.asarray(R))
    target=np.diag(np.r_[np.full(m,mean/m),np.full(n,(1-mean)/n)])
    lower=float(np.linalg.eigvalsh(B)[0]-q*N)
    return dict(covariance_max_error=float(np.max(np.abs(covariance-target))),
                decoder_matrix_difference=lower-task['decoder']['lower'])


def dense_constant_audit(r,m,n,a,b,q,task):
    """Dense fixed amplitudes and independent signs share the sparse gain."""
    h=np.r_[np.full(m,a),np.full(n,b)];w=np.r_[np.full(m,r/m),np.full(n,(1-r)/n)]
    D=q+r*task['zh']+(1-r)*task['zl']
    scale=np.r_[np.full(m,task['zh']/a/D),np.full(n,task['zl']/b/D)]
    d=m+n;B=np.zeros((d,d));cov=np.zeros((d,d));N=0.
    for sign in itertools.product([-1.,1.],repeat=d):
        u=np.asarray(sign)*np.sqrt(w);aa=scale*u;nn=np.sum(h*aa*aa)
        cov+=np.outer(u,u)/(2**d)
        B+=(np.outer(u,aa)+np.outer(aa,u)-nn*np.outer(u,u))/(2**d)
        N+=nn/(2**d)
    value=float(np.linalg.eigvalsh(B)[0]-q*N)
    sparse=finite_probe_audit([r],[1.],m,n,a,b,q,task)
    return dict(dense_gain=value,sparse_gain=task['decoder']['lower']+sparse['decoder_matrix_difference'],
                gain_difference=value-task['decoder']['lower']-sparse['decoder_matrix_difference'],
                dense_covariance_error=float(np.max(np.abs(cov-np.diag(w)))))


def one_case(name,m,n,a,b,q,r_fraction):
    optimum=linear_optimum(m,n,a,b,q);r0=m/(m+n);rs=optimum['rstar']
    r=r0+r_fraction*(rs-r0)
    H0=fixed_design([r],[1.],m,n,a,b,q)
    I0=fixed_design([r],[1.],m,n,1.,1.,q)
    zh,zl=H0['zh'],H0['zl'];xh,xl=I0['zh'],I0['zl']
    DH=q+r*zh+(1-r)*zl;DI=q+r*xh+(1-r)*xl
    KH=zh*zh*(zl+q)/a-zl*zl*(zh+q)/b
    KI=(xh-xl)*(xh*xl+q*(xh+xl))
    constants=dict(H_lower=(zh-zl)*KH/(q+zh)**3,
                   H_upper=(zh*zh/a-zl*zl/b)/(m*DH*DH),
                   I_lower=(xh-xl)*KI/(q+xl)**3,
                   I_upper=(xl*xl-xh*xh)/(n*DI*DI))
    assert min(constants.values())>0
    rows=[];radius=min(r,1-r)
    laws=[('symmetric',f,[r-f*radius,r+f*radius],[.5,.5])
          for f in [.01,.025,.05,.1,.2,.4,.7,1.]]
    laws.append(('endpoint_mixture',None,[r0,rs],[1-r_fraction,r_fraction]))
    for kind,f,RR,pp in laws:
        R=np.asarray(RR);p=np.asarray(pp);variance=float(p@((R-r)**2))
        H=fixed_design(R,p,m,n,a,b,q);I=fixed_design(R,p,m,n,1.,1.,q)
        metrics={}
        for label,base,actual,aa,bb,DD in [('H',H0,H,a,b,DH),('I',I0,I,1.,1.,DI)]:
            loss=base['value']-actual['value']
            frozen=float(p@fraction_terms(base['gamma'],R,m,n,aa,bb,q)[0])
            fixed=decoder_gain(R,p,m,n,aa,bb,q,base['zh'],base['zl'],DD)
            metrics[label]=dict(value=actual['value'],loss=loss,loss_over_variance=loss/variance,
                                relative_loss=loss/base['value'],raw_risk=1-actual['value'] if label=='I' else None,
                                frozen_prior_upper_gain=frozen,
                                fixed_denominator_primal_gain=fixed['lower'],
                                fixed_denominator_identity_error=(base['value']-fixed['lower'])-constants[label+'_upper']*variance,
                                lower_bound_slack=loss-constants[label+'_lower']*variance,
                                upper_bound_slack=constants[label+'_upper']*variance-loss,
                                primal_dual_gap=actual['primal_dual_gap'],
                                bounded_difference=actual['bounded_difference'],
                                bounded_success=actual['bounded_success'],
                                gamma=actual['gamma'],zh=actual['zh'],zl=actual['zl'],
                                optimum_derivative=actual['optimum_derivative'],
                                endpoint_derivatives=actual['endpoint_derivatives'],
                                analytic_second_derivative=actual['second_derivative'],
                                decoder=actual['decoder'])
        audit_H=finite_probe_audit(R,p,m,n,a,b,q,H)
        audit_I=finite_probe_audit(R,p,m,n,1.,1.,q,I)
        rows.append(dict(kind=kind,symmetric_radius_fraction=f,R=R.tolist(),p=p.tolist(),
                         mean_R=float(p@R),variance_R=variance,metrics=metrics,
                         covariance_max_error=max(audit_H['covariance_max_error'],audit_I['covariance_max_error']),
                         decoder_matrix_max_difference=max(abs(audit_H['decoder_matrix_difference']),abs(audit_I['decoder_matrix_difference']))))
    return dict(name=name,m=m,n=n,a=a,b=b,q=q,r_fraction=r_fraction,r0=r0,rstar=rs,r=r,
                scope='all measurable responses' if q>=1/3-1e-15 else 'linear responses only',
                same_covariance_diagonal=[r/m]*m+[(1-r)/n]*n,
                baseline=dict(H=H0,I=I0),constants=constants,laws=rows,
                dense_sparse_constant_R_checks=dict(
                    H=dense_constant_audit(r,m,n,a,b,q,H0),
                    I=dense_constant_audit(r,m,n,1.,1.,q,I0)))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,default=HERE)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True);start=time.monotonic()
    configurations=[('two_low_noise',1,1,4.,1.,.1),('two_q05',1,1,4.,1.,.5),
                    ('spiked_six',1,5,100.,1.,.5),('blocks_five',2,3,10.,1.,.5),
                    ('reversed_sizes_high_noise',3,2,25.,1.,10.),('mild_eight',4,4,2.,1.,.5)]
    cases=[one_case(*cfg,rf) for cfg in configurations for rf in [.25,.5,.75]]
    laws=[x for c in cases for x in c['laws']]
    allmetrics=[v for x in laws for v in x['metrics'].values()]
    summary=dict(cases=len(cases),nonconstant_laws=len(laws),task_comparisons=len(allmetrics),
                 min_strict_loss=min(v['loss'] for v in allmetrics),
                 min_variance_bound_slack=min(min(v['lower_bound_slack'],v['upper_bound_slack']) for v in allmetrics),
                 max_primal_dual_gap=max(abs(v['primal_dual_gap']) for v in allmetrics),
                 max_bounded_minimizer_difference=max(abs(v['bounded_difference']) for v in allmetrics),
                 all_bounded_solves_successful=all(v['bounded_success'] for v in allmetrics),
                 min_analytic_second_derivative=min(v['analytic_second_derivative'] for v in allmetrics),
                 max_fixed_denominator_identity_error=max(abs(v['fixed_denominator_identity_error']) for v in allmetrics),
                 max_covariance_error=max(v['covariance_max_error'] for v in laws),
                 max_decoder_matrix_difference=max(v['decoder_matrix_max_difference'] for v in laws),
                 max_dense_sparse_constant_R_gain_difference=max(abs(x['gain_difference']) for c in cases for x in c['dense_sparse_constant_R_checks'].values()),
                 seconds=time.monotonic()-start)
    assert summary['min_strict_loss']>0
    assert summary['min_variance_bound_slack']>-1e-12
    assert summary['max_primal_dual_gap']<1e-11
    assert summary['max_fixed_denominator_identity_error']<1e-11
    assert summary['max_covariance_error']<1e-12
    assert summary['max_decoder_matrix_difference']<1e-11
    assert summary['max_dense_sparse_constant_R_gain_difference']<1e-11
    output=dict(summary=summary,cases=cases,scope='Floating-point verification, not interval arithmetic. Each law has the same covariance as its constant-R baseline; every task response is reoptimized.')
    (args.out/'same_covariance_variance.json').write_text(json.dumps(output,indent=2))
    import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
    representative=next(c for c in cases if c['name']=='spiked_six' and c['r_fraction']==.5)
    fig,axes=plt.subplots(1,2,figsize=(9.4,3.7),layout='constrained')
    for ax,label,title in zip(axes,['I','H'],['Estimation loss','Optimization loss']):
        sym=[x for x in representative['laws'] if x['kind']=='symmetric']
        end=next(x for x in representative['laws'] if x['kind']=='endpoint_mixture')
        xs=np.array([x['variance_R'] for x in sym]);base=representative['baseline'][label]['value']
        ys=np.array([x['metrics'][label]['loss']/base for x in sym])
        span=np.geomspace(min(xs.min(),end['variance_R'])*.75,xs.max()*1.15,160)
        ax.loglog(span,representative['constants'][label+'_lower']*span/base,'--',color='#777777',label='Proved lower bound')
        ax.loglog(span,representative['constants'][label+'_upper']*span/base,':',color='#777777',label='Proved upper bound')
        ax.loglog(xs,ys,'o-',color='#0072B2',ms=4,label='Symmetric two-point law')
        ax.scatter([end['variance_R']],[end['metrics'][label]['loss']/base],marker='D',s=48,color='#D55E00',label='Endpoint mixture',zorder=5)
        ax.set(xlabel='Variance of block energy R',ylabel='Loss / constant-R task gain',title=title)
        ax.grid(which='both',alpha=.15)
    axes[0].legend(fontsize=7,loc='best')
    fig.suptitle('Same covariance, different decision quality: H=diag(100,1,1,1,1,1), q=0.5',fontsize=10)
    fig.savefig(args.out/'same_covariance_variance.pdf');fig.savefig(args.out/'same_covariance_variance.png',dpi=180)
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
