"""Exact two-level frontier and a selected endpoint-mixture design curve.

Run from any directory:
    python data/numerics/frontier_plot.py

The frontier is the closed-form constrained value at REQUIRED retention alpha.
The selected-mixture curve uses ACHIEVED estimation gain, with both decoders
reoptimized. The horizontal inactive-constraint segment is not a set of designs
having those smaller achieved estimation gains.

All numerical calculations and the plot use floating point, not interval proof.
"""
from pathlib import Path
import argparse
import json
import numpy as np

from same_covariance_variance import (
    fixed_design, linear_optimum, finite_probe_audit,
)


HERE = Path(__file__).resolve().parent
DEFAULT_FIGURES = HERE.parents[1] / "figures"


def dense_closed(r, m, n, a, b, q):
    total = m*a + n*b
    reciprocal = m*m*a/r + n*n*b/(1-r)
    directional = a*r+b*(1-r)
    linear = total+q*reciprocal
    return float(2/(linear+np.sqrt(
        linear*linear+reciprocal*directional-total*total)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--figure-dir", type=Path, default=DEFAULT_FIGURES)
    parser.add_argument("--json", type=Path, default=HERE/"frontier_plot.json")
    parser.add_argument("--points", type=int, default=401)
    args = parser.parse_args()
    args.figure_dir.mkdir(parents=True, exist_ok=True)
    args.json.parent.mkdir(parents=True, exist_ok=True)

    m, n, a, b, q = 1, 5, 100., 1., .5
    d = m+n
    r0 = m/d
    endpoint = linear_optimum(m, n, a, b, q)
    rs, Hstar = endpoint["rstar"], endpoint["value"]
    Istar = 1/(d*(1+d*q))
    alpha_star = dense_closed(rs, m, n, 1., 1., q)/Istar
    rmid = (r0+rs)/2

    def frontier(alpha):
        if alpha <= alpha_star:
            rr = rs
        elif alpha >= 1:
            rr = r0
        else:
            value = alpha*Istar
            C = (1-d*value/2)**2/(q*value+value*value/4)
            discriminant = max(0., (C-d*d)*(C-(m-n)**2))
            rr = min(rs, (C+m*m-n*n+np.sqrt(discriminant))/(2*C))
        hh = dense_closed(rr, m, n, a, b, q)
        ii = dense_closed(rr, m, n, 1., 1., q)
        return dict(required_retention=float(alpha), r=float(rr),
                    achieved_retention=ii/Istar, gain_H=hh, gain_I=ii,
                    normalized_progress=hh/Hstar,
                    constraint_active=bool(alpha > alpha_star))

    alphas = np.unique(np.r_[np.linspace(0., 1., args.points), alpha_star])
    frontier_rows = [frontier(float(alpha)) for alpha in alphas]

    mixture_rows = []
    for weight in np.linspace(0., 1., args.points):
        law_weights = [1-weight, weight]
        H = fixed_design([r0, rs], law_weights, m, n, a, b, q)
        I = fixed_design([r0, rs], law_weights, m, n, 1., 1., q)
        achieved = min(1., max(0., I["value"]/Istar))
        optimal = frontier(achieved)
        mixture_rows.append(dict(
            weight_on_progress_endpoint=float(weight),
            mean_R=float((1-weight)*r0+weight*rs),
            variance_R=float(weight*(1-weight)*(rs-r0)**2),
            gain_H=H["value"], gain_I=I["value"],
            achieved_retention=I["value"]/Istar,
            normalized_progress=H["value"]/Hstar,
            frontier_slack_at_achieved_retention=optimal["gain_H"]-H["value"],
            H_primal_dual_gap=H["primal_dual_gap"],
            I_primal_dual_gap=I["primal_dual_gap"],
            H_dual_block_prior=[H["zh"], H["zl"]],
            I_dual_block_prior=[I["zh"], I["zl"]],
        ))

    constant_H = fixed_design([rmid], [1.], m, n, a, b, q)
    constant_I = fixed_design([rmid], [1.], m, n, 1., 1., q)
    mixture_H = fixed_design([r0, rs], [.5, .5], m, n, a, b, q)
    mixture_I = fixed_design([r0, rs], [.5, .5], m, n, 1., 1., q)
    midpoint = dict(
        r=rmid, covariance_diagonal=[rmid/m]*m+[(1-rmid)/n]*n,
        balanced=dict(gain_H=constant_H["value"], gain_I=constant_I["value"],
                      retention=constant_I["value"]/Istar,
                      normalized_progress=constant_H["value"]/Hstar),
        selected_mixture=dict(gain_H=mixture_H["value"], gain_I=mixture_I["value"],
                      retention=mixture_I["value"]/Istar,
                      normalized_progress=mixture_H["value"]/Hstar),
        relative_improvement_over_mixture=dict(
            H=constant_H["value"]/mixture_H["value"]-1,
            I=constant_I["value"]/mixture_I["value"]-1),
        variance_R_mixture=.25*(rs-r0)**2,
    )
    audits = [
        finite_probe_audit([rmid], [1.], m, n, a, b, q, constant_H),
        finite_probe_audit([r0, rs], [.5, .5], m, n, a, b, q, mixture_H),
        finite_probe_audit([rmid], [1.], m, n, 1., 1., q, constant_I),
        finite_probe_audit([r0, rs], [.5, .5], m, n, 1., 1., q, mixture_I),
    ]
    closed_audit = []
    for rr in np.linspace(r0, rs, 13):
        for aa, bb in [(a,b),(1.,1.)]:
            closed_audit.append(abs(dense_closed(rr,m,n,aa,bb,q)
                -fixed_design([rr],[1.],m,n,aa,bb,q)["value"]))
    validation = dict(
        frontier_min_retention_slack=min(
            row["achieved_retention"]-row["required_retention"]
            for row in frontier_rows),
        selected_mixture_min_frontier_slack=min(
            row["frontier_slack_at_achieved_retention"] for row in mixture_rows),
        max_fixed_design_primal_dual_gap=max(
            max(abs(row["H_primal_dual_gap"]),abs(row["I_primal_dual_gap"]))
            for row in mixture_rows),
        max_closed_vs_scalar_dual_error=max(closed_audit),
        max_midpoint_covariance_error=max(
            audit["covariance_max_error"] for audit in audits),
        max_midpoint_decoder_enumeration_error=max(
            abs(audit["decoder_matrix_difference"]) for audit in audits),
        endpoint_H_closed_error=abs(dense_closed(rs,m,n,a,b,q)-Hstar),
        endpoint_I_closed_error=abs(dense_closed(r0,m,n,1.,1.,q)-Istar),
    )
    assert validation["frontier_min_retention_slack"] > -1e-11
    assert validation["selected_mixture_min_frontier_slack"] > -1e-11
    assert max(value for key,value in validation.items()
               if key.startswith("max_") or key.startswith("endpoint_")) < 1e-10
    assert midpoint["relative_improvement_over_mixture"]["H"] > 0
    assert midpoint["relative_improvement_over_mixture"]["I"] > 0

    caption = (
        "Exact two-task frontier for H_0=diag(100,1,1,1,1,1), q=0.5. "
        "The solid blue curve is the active Pareto frontier attained by "
        "constant block-energy two-eigendirection probes Q_r. The dotted "
        "horizontal segment shows the constrained value when the required "
        "estimation retention alpha is below alpha_*=0.5701; Q_{r_*} "
        "actually retains alpha_*, rather than the smaller x-axis value. "
        "The dashed orange curve is the achieved gain pair of the selected "
        "family (1-t)Q_{r_iso}+t Q_{r_*}, with both decoders reoptimized "
        "for each mixture; it is not the optimum over all endpoint-optimal "
        "laws. The marked 50:50 mixture and balanced probe at "
        "r=(r_iso+r_*)/2 have identical full covariance. Balancing improves "
        "their estimation and progress gains by 1.31% and 7.20%, respectively. "
        "The right panel enlarges this comparison. Floating-point plots "
        "illustrate the analytic results and are not numerical proofs."
    )
    output = dict(
        parameters=dict(m=m,n=n,a=a,b=b,q=q,r_iso=r0,r_star=rs,
                        I_star=Istar,J_H_star=Hstar,alpha_star=alpha_star),
        frontier_convention=(
            "x=required retention alpha; ordinate is F_q(1-alpha)/J_H_star. "
            "For alpha<=alpha_star, the displayed optimum is attained by "
            "a law whose achieved retention is alpha_star."),
        mixture_convention=(
            "x=achieved J_I/I_star, y=achieved J_H/J_H_star for the selected "
            "mixture (1-t)Q_riso+tQ_rstar, both decoders reoptimized. This "
            "curve is not an all-endpoint-mixture upper bound."),
        scope="q=0.5: exact minimax theory covers all measurable responses; plotted computations use floating point.",
        validation=validation, midpoint=midpoint,
        frontier=frontier_rows, selected_endpoint_mixture=mixture_rows,
        caption=caption,
    )
    args.json.write_text(json.dumps(output, indent=2)+"\n")

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.size":9, "axes.labelsize":9, "axes.titlesize":10,
        "legend.fontsize":8, "pdf.fonttype":42, "ps.fonttype":42,
        "axes.spines.top":False, "axes.spines.right":False,
    })
    blue, orange, dark = "#0072B2", "#D55E00", "#30343B"
    fig, axes = plt.subplots(1,2,figsize=(8.5,3.35),
                             gridspec_kw={"width_ratios":[1.55,1]},
                             layout="constrained")
    active = np.array([[row["required_retention"],row["normalized_progress"]]
                       for row in frontier_rows
                       if row["required_retention"]>=alpha_star-1e-14])
    mixed = np.array([[row["achieved_retention"],row["normalized_progress"]]
                      for row in mixture_rows])
    balanced = np.array([midpoint["balanced"]["retention"],
                         midpoint["balanced"]["normalized_progress"]])
    baseline = np.array([midpoint["selected_mixture"]["retention"],
                        midpoint["selected_mixture"]["normalized_progress"]])
    for ax in axes:
        ax.plot(active[:,0],active[:,1],color=blue,lw=2.3,
                label="Exact active frontier")
        ax.plot(mixed[:,0],mixed[:,1],color=orange,lw=2.0,ls=(0,(5,2.2)),
                label="Selected endpoint mixture")
        ax.scatter(*balanced,s=46,color=blue,edgecolor="white",linewidth=.7,
                   zorder=6,marker="o")
        ax.scatter(*baseline,s=46,color=orange,edgecolor="white",linewidth=.7,
                   zorder=6,marker="D")
        ax.annotate("",xy=balanced,xytext=baseline,
                    arrowprops=dict(arrowstyle="-|>",lw=1.2,color=dark,
                                    shrinkA=5,shrinkB=6),zorder=5)
        ax.grid(alpha=.18,lw=.6)
        ax.set_xlabel(r"Estimation retention, $\alpha$")
    axes[0].plot([0,alpha_star],[1,1],color=blue,lw=1.8,ls=":",
                 label="Inactive retention constraint")
    axes[0].scatter([alpha_star,1.],[1.,dense_closed(r0,m,n,a,b,q)/Hstar],
                    color=dark,s=26,zorder=5)
    axes[0].annotate(r"$Q_{r_*}$",(alpha_star,1.),xytext=(5,-17),
                     textcoords="offset points",fontsize=9,color=dark)
    axes[0].annotate(r"$Q_{r_{\rm iso}}$",
                    (1.,dense_closed(r0,m,n,a,b,q)/Hstar),
                    xytext=(-46,7),textcoords="offset points",
                    fontsize=9,color=dark)
    axes[0].set(xlim=(0,1.025),ylim=(.48,1.045),
                ylabel=r"Progress gain, $J_{H_0}/J_{H_0}^\star$",
                title="Complete constrained frontier")
    axes[0].legend(loc="lower left",frameon=False)
    axes[1].set(xlim=(.816,.867),ylim=(.797,.915),
                title="Equal covariance, better gains")
    axes[1].set_xticks([.82,.84,.86])
    axes[1].annotate("Balanced",balanced,xytext=(5,8),
                     textcoords="offset points",fontsize=9,color=blue)
    axes[1].annotate("50:50 mixture",baseline,xytext=(.819,.811),
                     textcoords="data",fontsize=8.5,color=orange)
    axes[1].text(.819,.882,"+1.31% estimation\n+7.20% progress",
                 ha="left",va="top",fontsize=8.5,color=dark,
                 bbox=dict(facecolor="white",edgecolor="none",alpha=.92,pad=2))
    fig.suptitle(r"$H_0=\mathrm{diag}(100,1,1,1,1,1),\quad q=0.5$",
                 fontsize=10)
    fig.savefig(args.figure_dir/"main_frontier.pdf",bbox_inches="tight")
    fig.savefig(args.figure_dir/"main_frontier.png",dpi=220,bbox_inches="tight")
    plt.close(fig)
    print(json.dumps(dict(parameters=output["parameters"],validation=validation,
                          midpoint=midpoint,caption=caption),indent=2))


if __name__ == "__main__":
    main()
