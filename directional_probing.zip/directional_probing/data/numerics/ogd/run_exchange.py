"""Practical exchange comparison on exactly the three OGD instances.

This finite-cut algorithm has no inherited OGD iteration-complexity claim.
Outputs include feasible decoder lower and continuous pair-oracle dual upper.
"""
from pathlib import Path
import json
import platform
import time

import cvxpy
import numpy
import scipy

from exchange_reference import exchange, jsonable


HERE = Path(__file__).resolve().parent
CASES = [('two_scales',[1,4]),('four_scales',[1,4,25,100]),('spiked_six',[1,1,1,1,1,100])]


def main():
    data = dict(metadata=dict(python=platform.python_version(),numpy=numpy.__version__,
                              scipy=scipy.__version__,cvxpy=cvxpy.__version__,
                              q=1.0,omega=.5,requested_exchange_atol=5e-8,
                              required_feasible_gap=1e-6,
                              claim='Floating point a posteriori primal-dual gap; no interval proof and no OGD complexity inheritance'),
                cases=[])
    for name,h in CASES:
        start=time.perf_counter()
        try:
            result=exchange(h,1.0,.5,atol=5e-8,max_rounds=100)
            result['runtime_seconds']=time.perf_counter()-start
            result['name']=name
            result['meets_gap_target']=bool(result['certificate_gap']<=1e-6)
            result['completed']=True
            print(name,'lower',result['feasible_lower'],'upper',result['upper'],
                  'gap',result['certificate_gap'],'seconds',result['runtime_seconds'],flush=True)
        except Exception as error:
            result=dict(name=name,h=h,completed=False,error=repr(error),
                        runtime_seconds=time.perf_counter()-start)
            print(name,'FAILED',repr(error),flush=True)
        data['cases'].append(result)
        (HERE/'exchange_results.json').write_text(json.dumps(jsonable(data),indent=2)+'\n')


if __name__=='__main__':
    main()
