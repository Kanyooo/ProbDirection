"""Numerical audit of two-task one-probe designs (G=1).

Independent convex dual + exact two-coordinate separation oracle.  The global
validity of the separation oracle uses the two-support reduction theorem;
random full-simplex oracle checks are also recorded, but are not a proof.

Task E is gradient MSE improvement J_E=1-R; task O is J_O=2V.
Outputs contain BOTH feasible-decoder lower and dual upper values.
"""
from __future__ import annotations

import argparse
import itertools
import json
import platform
import time
from pathlib import Path

import cvxpy as cp
import numpy as np
from scipy.optimize import brentq, minimize


SOLVER_OPTIONS = dict(solver="CLARABEL", tol_gap_abs=2e-10,
                      tol_gap_rel=2e-10, tol_feas=2e-10, max_iter=300)


def spectral_optimum(h, q):
    h = np.asarray(h, float)
    def residual(t):
        return np.sum((t*h + np.sqrt(t*t*h*h+4*q*t*h))/2)-1
    t = 1/np.sum(h) if q==0 else brentq(residual, 0, 1/np.sum(h), xtol=1e-15)
    z = (t*h + np.sqrt(t*t*h*h+4*q*t*h))/2
    S = np.sum(z/(z+2*q))
    D = 1-q*S
    p = z*(z+q)/(D*(z+2*q))
    w = z/(S*(z+2*q))
    return dict(t=float(t), z=z, p=p, w=w)


def task_fraction(W, z, h, q):
    return (W @ (z*z/h))/(W @ z + q)


def exact_pair_oracle(z, x, h, q, weights):
    """Maximize weighted sum of two linear fractions over simplex edges.

    On each edge the derivative has a quadratic numerator.  All real roots
    within [0,1] and both endpoints are checked; no local numerical maximize.
    """
    d = len(h)
    co, ce = weights
    A, C = z*z/h, x*x
    best = (-np.inf, None)
    candidates = []
    for i, j in itertools.combinations(range(d), 2):
        a0, da = A[j], A[i]-A[j]
        b0, db = z[j]+q, z[i]-z[j]
        c0, dc = C[j], C[i]-C[j]
        d0, dd = x[j]+q, x[i]-x[j]
        ko = co*(da*b0-a0*db)
        ke = ce*(dc*d0-c0*dd)
        coef = np.array([ko*dd*dd+ke*db*db,
                         2*(ko*d0*dd+ke*b0*db),
                         ko*d0*d0+ke*b0*b0])
        scale = np.max(np.abs(coef))
        ts = [0., 1.]
        if scale > 1e-30:
            normcoef = np.trim_zeros(np.where(np.abs(coef/scale)<1e-13, 0, coef/scale), 'f')
            if len(normcoef)>1:
                for root in np.roots(normcoef):
                    if abs(root.imag)<1e-8 and 0 < root.real < 1:
                        ts.append(float(root.real))
        for t in ts:
            W = np.zeros(d)
            W[i], W[j] = t, 1-t
            val = co*task_fraction(W,z,h,q)+ce*task_fraction(W,x,np.ones(d),q)
            candidates.append((float(val), W))
            if val > best[0]:
                best = (float(val), W)
    if d == 1:
        W=np.ones(1)
        return float(co*task_fraction(W,z,h,q)+ce*task_fraction(W,x,np.ones(d),q)), W, []
    candidates.sort(key=lambda a:a[0],reverse=True)
    return best[0], best[1], candidates


def finite_dual(W, h, q, weights):
    d = len(h)
    z = cp.Variable(d, nonneg=True)
    x = cp.Variable(d, nonneg=True)
    rho = cp.Variable()
    co,ce = weights
    constraints=[cp.sum(z)==1, cp.sum(x)==1]
    cuts=[]
    denomscale=max(1.,q)
    for w in W:
        expr=cp.quad_over_lin(cp.multiply(np.sqrt(co*w/h/denomscale),z), (w@z+q)/denomscale)
        expr+=cp.quad_over_lin(cp.multiply(np.sqrt(ce*w/denomscale),x), (w@x+q)/denomscale)
        cut=expr<=rho
        constraints.append(cut)
        cuts.append(cut)
    prob=cp.Problem(cp.Minimize(rho),constraints)
    try:
        prob.solve(**SOLVER_OPTIONS)
    except cp.error.SolverError:
        prob.solve(solver='CLARABEL',tol_gap_abs=1e-8,tol_gap_rel=1e-8,tol_feas=1e-8,max_iter=300)
    if prob.status not in ("optimal", "optimal_inaccurate"):
        raise RuntimeError(prob.status)
    p=np.maximum(np.asarray([cut.dual_value for cut in cuts]).reshape(-1),0)
    p=p/p.sum()
    zv=np.maximum(np.asarray(z.value),0);zv/=zv.sum()
    xv=np.maximum(np.asarray(x.value),0);xv/=xv.sum()
    return float(prob.value),zv,xv,p,prob.status


def decoder_value(W,p,z,h,q):
    r=W@z+q
    N_each=(W@(z*z/h))/(r*r)
    B=np.sum(p[:,None]*(2*W*z[None,:]/h[None,:]/r[:,None]-W*N_each[:,None]),axis=0)
    noise=q*np.dot(p,N_each)
    return float(np.min(B)-noise),B,float(noise)


def fixed_design_task(W,p,h,q):
    d=len(h)
    def fg(z):
        r=W@z+q
        numer=W@(z*z/h)
        val=np.dot(p,numer/r)
        grad=np.sum(p[:,None]*(2*W*z[None,:]/h[None,:]/r[:,None]-W*(numer/r**2)[:,None]),axis=0)
        return val,grad
    scale=1/max(spectral_optimum(h,q)['t'],1e-15)
    res=minimize(lambda z:scale*fg(z)[0],np.ones(d)/d,jac=lambda z:scale*fg(z)[1],
                 bounds=[(0,1)]*d,constraints=[{'type':'eq','fun':lambda z:np.sum(z)-1,'jac':lambda z:np.ones(d)}],
                 method='SLSQP',options=dict(ftol=1e-13,maxiter=1000))
    z=res.x
    v,B,noise=decoder_value(W,p,z,h,q)
    return dict(lower=v,upper=float(fg(z)[0]),z=z,B=B,noise=noise,solver_success=bool(res.success))


def exchange(h,q,alpha,atol=2e-8,max_rounds=100,seed=42):
    """Normalized support alpha*JO/JOstar + (1-alpha)*JE/JEstar."""
    h=np.asarray(h,float)
    d=len(h)
    so=spectral_optimum(h,q)
    je_star=1/(d*(1+d*q))
    weights=(alpha/so['t'],(1-alpha)/je_star)
    W=np.eye(d)
    # Pair midpoints speed discovery without presupposing dense optimality.
    W=np.vstack([W,*[(np.eye(d)[i]+np.eye(d)[j])/2 for i,j in itertools.combinations(range(d),2)]])
    logs=[]
    start=time.time()
    for it in range(max_rounds):
        lower_dual,z,x,p,status=finite_dual(W,h,q,weights)
        upper,wnew,candidates=exact_pair_oracle(z,x,h,q,weights)
        gap=upper-lower_dual
        logs.append(dict(round=it,n_cuts=len(W),restricted_dual=lower_dual,
                         separated_upper=upper,gap=gap,status=status))
        if gap<=atol:
            break
        new=[]
        for val,w in candidates:
            if val-lower_dual<=atol/2:
                break
            if np.min(np.linalg.norm(W-w,axis=1))>1e-7 and (not new or min(np.linalg.norm(wn-w) for wn in new)>1e-7):
                new.append(w)
            if len(new)>=d:
                break
        if not new:
            break
        W=np.vstack([W,*new])
    else:
        raise RuntimeError("Exchange exhausted max_rounds")
    # Remove numerically inactive cuts, then resolve individual decoders to
    # obtain actual minimax task values for the recovered probing mixture.
    active=p>1e-8
    WP,pp=W[active],p[active]
    pp/=pp.sum()
    O=fixed_design_task(WP,pp,h,q)
    E=fixed_design_task(WP,pp,np.ones(d),q)
    feasible=weights[0]*O['lower']+weights[1]*E['lower']
    rng=np.random.default_rng(seed)
    Wr=rng.dirichlet(np.ones(d)*0.3,size=20000)
    random_max=float(np.max(weights[0]*task_fraction(Wr,z,h,q)+weights[1]*task_fraction(Wr,x,np.ones(d),q)))
    result=dict(alpha=float(alpha),weights=weights,q=q,h=h,upper=upper,
                feasible_lower=feasible,certificate_gap=upper-feasible,
                JO=O,JE=E,JO_star=so['t'],JE_star=je_star,
                epsilon=1-E['lower']/je_star,efficiency=O['lower']/so['t'],
                W=WP,p=pp,adversary_z=z,adversary_x=x,
                full_simplex_random_max=random_max,random_oracle_excess=random_max-upper,
                exchange=logs,seconds=time.time()-start)
    return result


def coordinate_only(h,q,alpha):
    h=np.asarray(h,float)
    d=len(h)
    jo_star=spectral_optimum(h,q)['t']
    je_star=1/(d*(1+d*q))
    weights=(alpha/jo_star,(1-alpha)/je_star)
    W=np.eye(d)
    val,z,x,p,status=finite_dual(W,h,q,weights)
    O=fixed_design_task(W,p,h,q)
    E=fixed_design_task(W,p,np.ones(d),q)
    return dict(alpha=alpha,epsilon=1-E['lower']/je_star,efficiency=O['lower']/jo_star,
                upper=val,feasible_lower=weights[0]*O['lower']+weights[1]*E['lower'],p=p,JO=O,JE=E)


def jsonable(x):
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,(np.floating,np.integer)): return x.item()
    if isinstance(x,dict): return {k:jsonable(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)): return [jsonable(v) for v in x]
    return x


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--quick',action='store_true')
    parser.add_argument('--out',default=str(Path(__file__).parent))
    args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    alphas=[.1,.5,.9] if args.quick else [.0001,.001,.005,.01,.03,.05,.1,.15,.2,.3,.4,.5,.6,.7,.8,.85,.9,.95,.97,.99,.995,.999,.9999]
    cases={'four_scales':[1,4,25,100], 'spiked_six':[1,1,1,1,1,100]}
    data={'metadata':dict(python=platform.python_version(),numpy=np.__version__,cvxpy=cp.__version__,solver='CLARABEL',q=1,seed=42), 'cases':{},'coordinate_only':{}}
    for name,h in cases.items():
        rows=[]
        coords=[]
        for a in alphas:
            r=exchange(h,1.,a)
            rows.append(r)
            coords.append(coordinate_only(h,1.,a))
            print(name,a,'eps',round(r['epsilon'],6),'eff',round(r['efficiency'],6),'gap',r['certificate_gap'],'cuts',len(r['W']),flush=True)
            data['cases'][name]=rows
            data['coordinate_only'][name]=coords
            (out/'tradeoff_results.json').write_text(json.dumps(jsonable(data),indent=2))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(1,2,figsize=(10,4),layout='constrained')
    for ax,(name,rows) in zip(axs,cases_results(data)):
        eps=np.array([r['epsilon'] for r in rows])
        eff=np.array([r['efficiency'] for r in rows])
        ax.plot(eps,eff,'o-',markersize=4,label='All probing distributions')
        cr=data['coordinate_only'][name]
        ax.plot([r['epsilon'] for r in cr],[r['efficiency'] for r in cr],'s--',markersize=3,label='Coordinate-only designs')
        ax.set(xlabel='Fraction of optimal estimation improvement forgone',ylabel='Optimization efficiency $J_O/J_O^*$',title=name.replace('_',' '))
        ax.grid(alpha=.25)
        ax.legend(fontsize=8)
    fig.savefig(out/'tradeoff_frontier.png',dpi=180)
    fig.savefig(out/'tradeoff_frontier.pdf')


def cases_results(data):
    return data['cases'].items()


if __name__=='__main__':
    main()
