"""Independent finite-difference, edge-grid, and saved-certificate diagnostics."""
import itertools
import json
from pathlib import Path

import numpy as np

from pair_ogd import pair_oracle, task_value_gradient, jsonable


HERE=Path(__file__).resolve().parent


def independent_decoder(W,z,h,q,groups):
    signal=W@z
    numerator=np.sum(W*(z*z/h),axis=1)
    energy=numerator/(q+signal)**2
    reward_diagonal=np.mean(2*W*z/h/(q+signal)[:,None]-W*energy[:,None],axis=0)
    for group in groups:
        reward_diagonal[group]=np.mean(reward_diagonal[group])
    return float(np.min(reward_diagonal)-q*np.mean(energy))


def main():
    data=json.loads((HERE/'ogd_results.json').read_text())
    max_upper_error,max_lower_error,max_bound_excess=0.,0.,-np.inf
    for run in data['runs']:
        h=np.array(run['h']); q=run['q']; co,ce=run['weights']
        W=np.array(run['raw_bestresponse_atoms'])
        groups=[np.array(g) for g in run.get('equal_h_groups',[])]
        for row in run['checkpoints']:
            z,x=map(np.array,row['upper_priors'])
            upper,_=pair_oracle(z,x,h,q,co,ce)
            lower=co*independent_decoder(W[:row['T']],np.array(row['optimization']['prior']),h,q,groups)
            lower+=ce*independent_decoder(W[:row['T']],np.array(row['estimation']['prior']),np.ones(len(h)),q,groups)
            max_upper_error=max(max_upper_error,abs(upper-row['dual_upper']))
            max_lower_error=max(max_lower_error,abs(lower-row['feasible_decoder_lower']))
            max_bound_excess=max(max_bound_excess,row['primal_dual_gap']-row['theorem_decoder_gap_bound'])
            assert row['primal_dual_gap']>=-1e-10
    assert max_upper_error<1e-10 and max_lower_error<1e-10 and max_bound_excess<1e-8

    rng=np.random.default_rng(19017)
    max_gradient_error,max_grid_excess=0.,-np.inf
    cases=0
    for d in [2,4,6]:
        for q in [.05,.5,1.,10.]:
            for _ in range(5):
                h=np.exp(rng.uniform(0,np.log(100),d))
                z,x=rng.dirichlet(np.ones(d),size=2)
                W=rng.dirichlet(np.ones(d))
                value,grad=task_value_gradient(z,W,h,q)
                eps=1e-6
                for i in range(d):
                    dz=np.eye(d)[i]*eps
                    fplus=np.sum((z+dz)**2*W/h)/(q+W@(z+dz))
                    fminus=np.sum((z-dz)**2*W/h)/(q+W@(z-dz))
                    max_gradient_error=max(max_gradient_error,abs(grad[i]-(fplus-fminus)/(2*eps)))
                co,ce=np.exp(rng.uniform(-2,2,2))
                oracle,_=pair_oracle(z,x,h,q,co,ce)
                ts=np.linspace(0,1,1001)
                for i,j in itertools.combinations(range(d),2):
                    edge=np.zeros((len(ts),d)); edge[:,i]=ts;edge[:,j]=1-ts
                    vals=co*(edge@(z*z/h))/(q+edge@z)+ce*(edge@(x*x))/(q+edge@x)
                    max_grid_excess=max(max_grid_excess,float(vals.max()-oracle))
                cases+=1
    assert max_gradient_error<1e-8 and max_grid_excess<1e-10

    ex=json.loads((HERE/'exchange_results.json').read_text())
    exchange_checks=[]
    for case in ex['cases']:
        assert case['completed']
        h=np.array(case['h']);q=case['q'];co,ce=case['weights']
        W=np.array(case['W']);p=np.array(case['p'])
        def decoder(z,metric):
            r=q+W@z
            energy=(W@(z*z/metric))/r**2
            B=np.sum(p[:,None]*(2*W*z/metric/r[:,None]-W*energy[:,None]),axis=0)
            return float(B.min()-q*(p@energy))
        lower=co*decoder(np.array(case['JO']['z']),h)+ce*decoder(np.array(case['JE']['z']),np.ones(len(h)))
        upper,_=pair_oracle(np.array(case['adversary_z']),np.array(case['adversary_x']),h,q,co,ce)
        assert abs(lower-case['feasible_lower'])<1e-10
        assert abs(upper-case['upper'])<1e-10
        assert 0<=upper-lower<=1e-6
        exchange_checks.append(dict(name=case['name'],recomputed_lower=lower,recomputed_upper=upper,gap=upper-lower))
    result=dict(checkpoints=sum(len(r['checkpoints']) for r in data['runs']),
                max_saved_upper_recomputation_error=max_upper_error,
                max_saved_lower_recomputation_error=max_lower_error,
                max_observed_gap_minus_theorem_bound=max_bound_excess,
                random_derivative_and_edge_cases=cases,
                max_gradient_finite_difference_error=max_gradient_error,
                max_edge_grid_minus_continuous_oracle=max_grid_excess,
                exchange=exchange_checks,
                status='PASS',scope='Floating numerical diagnostics; grids and random samples are not a global proof')
    (HERE/'audit_results.json').write_text(json.dumps(jsonable(result),indent=2)+'\n')
    print(json.dumps(jsonable(result),indent=2))


if __name__=='__main__':
    main()
