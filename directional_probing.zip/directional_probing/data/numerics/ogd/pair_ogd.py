"""Exact-edge best response and projected OGD for two quadratic tasks.

From the repository root: python data/numerics/ogd/pair_ogd.py
The mathematical oracle checks every stationary point on every simplex edge.
Its implementation and all optimization checks use floating point, not intervals.
Output paths resolve against this file, never the caller's current directory.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
import platform
import time
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import brentq, minimize


HERE = Path(__file__).resolve().parent
CHECKPOINTS = (64, 256, 1024, 4096)


def jsonable(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, (np.floating, np.integer, np.bool_)):
        return x.item()
    if isinstance(x, dict):
        return {k: jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonable(v) for v in x]
    return x


def project_simplex(v):
    """Euclidean projection on the probability simplex."""
    v = np.asarray(v, float)
    u = np.sort(v)[::-1]
    css = np.cumsum(u) - 1.0
    rho = np.flatnonzero(u - css / np.arange(1, len(v) + 1) > 0)[-1]
    ans = np.maximum(v - css[rho] / (rho + 1), 0.0)
    # Remove sum roundoff before evaluating feasible-point bounds.
    return ans / ans.sum()


def spectral_optimum(h, q):
    h = np.asarray(h, float)
    if q == 0:
        return 1.0 / h.sum()
    def residual(t):
        return np.sum((t*h + np.sqrt(t*t*h*h + 4*q*t*h))/2) - 1
    return brentq(residual, 0, 1/h.sum(), xtol=1e-15)


def task_value_gradient(z, W, h, q):
    """Value and gradient for one squared-amplitude atom W."""
    r = q + W @ z
    numerator = W @ (z*z/h)
    return float(numerator/r), W*(2*z/(h*r) - numerator/r**2)


def pair_oracle(z, x, h, q, co, ce):
    """Continuous pair oracle: endpoints plus all real quadratic roots.

    On W=t e_i+(1-t)e_j the derivative is
      ko/(b0+db*t)^2 + ke/(d0+dd*t)^2.
    Its numerator is quadratic. All candidates are evaluated directly.
    Two-support sufficiency is a theorem, not inferred from this computation.
    """
    d = len(h)
    if d == 1:
        W = np.ones(1)
        return co*task_value_gradient(z,W,h,q)[0] + ce*task_value_gradient(x,W,np.ones(d),q)[0], W
    A, C = z*z/h, x*x
    best_value, best_pair = -np.inf, None
    for i, j in itertools.combinations(range(d), 2):
        a0, da = A[j], A[i]-A[j]
        b0, db = z[j]+q, z[i]-z[j]
        c0, dc = C[j], C[i]-C[j]
        d0, dd = x[j]+q, x[i]-x[j]
        ko, ke = co*(da*b0-a0*db), ce*(dc*d0-c0*dd)
        coef = np.array([ko*dd*dd+ke*db*db,
                         2*(ko*d0*dd+ke*b0*db),
                         ko*d0*d0+ke*b0*b0])
        candidates = [0.0, 1.0]
        scale = np.max(np.abs(coef))
        if scale > 0:
            normalized = np.trim_zeros(coef/scale, 'f')
            if len(normalized) > 1:
                for root in np.roots(normalized):
                    if abs(root.imag) < 1e-9 and 0 < root.real < 1:
                        candidates.append(float(root.real))
        for t in candidates:
            value = co*(a0+da*t)/(b0+db*t) + ce*(c0+dc*t)/(d0+dd*t)
            if value > best_value:
                best_value = float(value)
                best_pair = (i,j,t)
    best_w = np.zeros(d)
    i,j,t = best_pair
    best_w[i], best_w[j] = t, 1-t
    return best_value, best_w


def average_equal_blocks(v, groups):
    v = np.asarray(v, float).copy()
    for group in groups:
        v[group] = np.mean(v[group])
    return v


def fixed_law_recovery(W, h, q, groups=()):
    """Independently fit a decoder, and report its actual worst-direction gain.

    Merely minimizing the prior objective returns an upper bound. The lower
    bound reported here is value minus its Frank--Wolfe gap, equal to the
    minimum diagonal gain of the associated feasible response function.
    """
    d = len(h)
    def fg(z):
        z = average_equal_blocks(z, groups)
        r = q + W @ z
        numer = W @ (z*z/h)
        value = np.mean(numer/r)
        grad = np.mean(2*W*z[None,:]/h[None,:]/r[:,None]
                       - W*(numer/r**2)[:,None], axis=0)
        return float(value), average_equal_blocks(grad, groups)
    scale = 1/spectral_optimum(h, q)
    result = minimize(lambda z: scale*fg(z)[0], np.ones(d)/d,
                      jac=lambda z: scale*fg(z)[1], method='SLSQP',
                      bounds=[(0,1)]*d,
                      constraints=[dict(type='eq', fun=lambda z: z.sum()-1,
                                        jac=lambda z: np.ones(d))],
                      options=dict(ftol=2e-13, maxiter=1000))
    z = average_equal_blocks(project_simplex(result.x), groups)
    value, grad = fg(z)
    fw_gap = float(z@grad - grad.min())
    r = q + W@z
    atom_norm2 = (W@(z*z/h))/r**2
    B = np.mean(2*W*z[None,:]/h[None,:]/r[:,None]
                - W*atom_norm2[:,None], axis=0)
    B = average_equal_blocks(B, groups)
    noise = q*float(np.mean(atom_norm2))
    lower = float(B.min()-noise)
    assert abs(lower-(value-fw_gap)) < 5e-12
    return dict(prior=z, objective_upper=value, decoder_lower=lower,
                fw_residual=max(0.0,fw_gap), B=B, noise_penalty=noise,
                success=bool(result.success), status=str(result.message),
                iterations=int(result.nit), identity_residual=abs(lower-(value-fw_gap)))


def run_case(name, h, q=1.0, omega=.5, horizon=4096, schedule='theorem', symmetrize=False):
    h = np.asarray(h, float)
    d = len(h)
    groups = [np.flatnonzero(h == value) for value in np.unique(h)] if symmetrize else []
    jo_star = spectral_optimum(h, q)
    je_star = 1/(d*(1+d*q))
    co, ce = omega/jo_star, (1-omega)/je_star
    weights = np.array([co, ce])
    R0 = math.sqrt(1-1/d)
    c_q = 2/(q+1) + (1/(4*q) if q <= 1 else 1/(q+1)**2)
    G = np.array([c_q/h.min(), c_q])
    eta_fixed = R0/(G*math.sqrt(horizon))
    z = np.ones(d)/d
    x = z.copy()
    W_history, upper_history, gradient_norm_history, eta_history = [], [], [], []
    cumulative_sq = np.zeros(2)
    sum_eta_norm2 = np.zeros(2)
    best_upper = np.inf
    best_priors = None
    cumulative_z = np.zeros(d)
    cumulative_x = np.zeros(d)
    rows = []
    start = time.time()
    for t in range(1, horizon+1):
        cumulative_z += z
        cumulative_x += x
        value, W = pair_oracle(z,x,h,q,co,ce)
        if value < best_upper:
            best_upper = value
            best_priors = [z.copy(), x.copy()]
        _, go = task_value_gradient(z,W,h,q)
        _, ge = task_value_gradient(x,W,np.ones(d),q)
        # For equal-h blocks with constant dual priors, every permutation of W
        # is also a best response. Average over that finite orbit; each sampled
        # direction still has at most two nonzero coordinates. Computing the
        # orbit expectation through block averages avoids storing duplicates.
        go = average_equal_blocks(go, groups)
        ge = average_equal_blocks(ge, groups)
        norm2 = np.array([go@go, ge@ge])
        cumulative_sq += norm2
        eta = eta_fixed if schedule == 'theorem' else math.sqrt(2)/np.sqrt(np.maximum(cumulative_sq,1e-300))
        sum_eta_norm2 += eta*norm2
        W_history.append(W)
        upper_history.append(value)
        gradient_norm_history.append(np.sqrt(norm2))
        eta_history.append(eta.copy())
        z = average_equal_blocks(project_simplex(z-eta[0]*go), groups)
        x = average_equal_blocks(project_simplex(x-eta[1]*ge), groups)
        if t in CHECKPOINTS or t == horizon:
            W_all = np.asarray(W_history)
            average_z = project_simplex(cumulative_z/t)
            average_x = project_simplex(cumulative_x/t)
            average_upper, _ = pair_oracle(average_z,average_x,h,q,co,ce)
            output_upper = min(best_upper,average_upper)
            output_priors = best_priors if best_upper <= average_upper else [average_z,average_x]
            O = fixed_law_recovery(W_all,h,q,groups)
            E = fixed_law_recovery(W_all,np.ones(d),q,groups)
            lower = co*O['decoder_lower'] + ce*E['decoder_lower']
            recovery_residual = co*O['fw_residual'] + ce*E['fw_residual']
            if schedule == 'theorem':
                regret = np.dot(weights, R0**2/(2*eta_fixed*t) + eta_fixed*G**2/2)
            else:
                # Product blocks have squared diameter 2. Decreasing eta_t:
                # R_T <= D^2/(2 eta_T) + (1/2) sum eta_t ||g_t||^2.
                regret = np.dot(weights, 1/eta + sum_eta_norm2/2)/t
            row = dict(T=t, dual_upper=output_upper, historical_dual_upper=best_upper,
                       averaged_dual_upper=average_upper, feasible_decoder_lower=lower,
                       primal_dual_gap=output_upper-lower,
                       fixed_law_recovery_residual=recovery_residual,
                       theorem_game_gap_bound=float(regret),
                       theorem_decoder_gap_bound=float(regret+recovery_residual),
                       optimization=O, estimation=E,
                       upper_priors=output_priors,
                       JO_efficiency=O['decoder_lower']/jo_star,
                       JE_efficiency=E['decoder_lower']/je_star,
                       elapsed_seconds=time.time()-start)
            rows.append(row)
            print(f'{name:15s} {schedule:8s} sym={symmetrize} T={t:4d} lower={lower:.8f} upper={output_upper:.8f} gap={output_upper-lower:.5g} bound={regret:.5g}', flush=True)
    W_all = np.asarray(W_history)
    norms = np.asarray(gradient_norm_history)
    # Independent diagnostics: random full-simplex samples at the upper priors.
    rng = np.random.default_rng(192703)
    dense_W = rng.dirichlet(np.full(d,.7),size=10000)
    bz,bx=rows[-1]['upper_priors']
    values = co*(dense_W@(bz*bz/h))/(q+dense_W@bz) + ce*(dense_W@(bx*bx))/(q+dense_W@bx)
    return dict(name=name,h=h,q=q,omega=omega,horizon=horizon,schedule=schedule,
                symmetrize_equal_h=symmetrize,equal_h_groups=groups,
                empirical_law='Uniform iterate, then uniform within-block coordinate permutation, then independent Rademacher signs' if symmetrize else 'Uniform iterate, then independent Rademacher signs',
                JO_star=jo_star,JE_star=je_star,weights=weights,
                normalized_game_weights=weights/weights.sum(),weight_sum=weights.sum(),
                initial_radius=R0,gradient_bounds=G,fixed_steps=eta_fixed,
                checkpoints=rows,raw_bestresponse_atoms=W_all,
                raw_oracle_values=upper_history,raw_gradient_norms=norms,
                raw_steps=eta_history,
                checks=dict(max_atom_sum_residual=float(np.max(abs(W_all.sum(axis=1)-1))),
                            min_atom_coordinate=float(W_all.min()),
                            max_atom_support=int(np.max(np.sum(W_all>0,axis=1))),
                            max_gradient_bound_ratio=np.max(norms/G,axis=0),
                            random_full_simplex_excess=float(values.max()-rows[-1]['dual_upper']),
                            random_samples=len(dense_W),
                            all_recovery_optimizers_succeeded=all(r['optimization']['success'] and r['estimation']['success'] for r in rows)))


def plot_results(data, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    names = list(dict.fromkeys(r['name'] for r in data['runs']))
    fig, axes = plt.subplots(1,len(names),figsize=(12,3.7),layout='constrained')
    for ax,name in zip(np.atleast_1d(axes),names):
        for run in (r for r in data['runs'] if r['name']==name):
            rows=run['checkpoints']
            T=[r['T'] for r in rows]
            color='tab:green' if run.get('symmetrize_equal_h',False) else ('tab:blue' if run['schedule']=='theorem' else 'tab:orange')
            label='Fixed theorem step' if run['schedule']=='theorem' else 'Block AdaGrad step'
            if run.get('symmetrize_equal_h',False):
                label='Block AdaGrad + symmetry'
            ax.loglog(T,[r['primal_dual_gap'] for r in rows],'o-',color=color,label=label)
            ax.loglog(T,[r['theorem_decoder_gap_bound'] for r in rows],'--',color=color,alpha=.6,label=label+' bound')
        ax.set(title=name.replace('_',' '),xlabel='Oracle calls $T$',ylabel='Normalized support gap')
        ax.grid(which='both',alpha=.2)
        ax.legend(fontsize=6)
    fig.suptitle('General-spectrum pair best response + projected OGD; q = 1, omega = 0.5',fontsize=10)
    fig.savefig(out/'ogd_convergence.png',dpi=180)
    fig.savefig(out/'ogd_convergence.pdf')
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=HERE)
    parser.add_argument('--horizon',type=int,default=4096)
    parser.add_argument('--adaptive',action='store_true',help='Also run an explicitly labeled block AdaGrad comparison')
    parser.add_argument('--symmetrize',action='store_true',help='Also run equal-h permutation averaging for the spiked spectrum with AdaGrad')
    parser.add_argument('--reuse',action='store_true',help='Reuse matching completed runs in the output JSON')
    args = parser.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    cases = [('two_scales',[1,4]),('four_scales',[1,4,25,100]),('spiked_six',[1,1,1,1,1,100])]
    schedules=['theorem','adaptive'] if args.adaptive else ['theorem']
    data=dict(metadata=dict(python=platform.python_version(),numpy=np.__version__,
                           scipy=scipy.__version__,float_arithmetic=True,
                           claim='Feasible decoder lower and continuous pair-oracle upper; no interval certification',
                           horizon=args.horizon),runs=[])
    old_runs=[]
    if args.reuse and (args.out/'ogd_results.json').exists():
        old_runs=json.loads((args.out/'ogd_results.json').read_text())['runs']
    for name,h in cases:
        for schedule in schedules:
            reused=next((r for r in old_runs if r['name']==name and r['schedule']==schedule
                         and r['horizon']==args.horizon and not r.get('symmetrize_equal_h',False)),None)
            data['runs'].append(reused if reused is not None else run_case(name,h,horizon=args.horizon,schedule=schedule))
            (args.out/'ogd_results.json').write_text(json.dumps(jsonable(data),indent=2)+'\n')
    if args.symmetrize:
        reused=next((r for r in old_runs if r['name']=='spiked_six' and r['schedule']=='adaptive'
                     and r['horizon']==args.horizon and r.get('symmetrize_equal_h',False)),None)
        data['runs'].append(reused if reused is not None else run_case('spiked_six',cases[-1][1],horizon=args.horizon,schedule='adaptive',symmetrize=True))
        (args.out/'ogd_results.json').write_text(json.dumps(jsonable(data),indent=2)+'\n')
    plot_results(data,args.out)


if __name__=='__main__':
    main()
