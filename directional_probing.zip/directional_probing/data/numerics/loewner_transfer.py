"""Small floating-point audit of policy transfer under noncommuting perturbations.

Uses the analytic exact two-level frontier as a reference, never interprets a
numerical eigenvalue calculation as an interval-arithmetic proof.
"""
from pathlib import Path
import itertools
import json
import numpy as np

HERE=Path(__file__).resolve().parent


def atoms(m,n,r,kind):
    d=m+n
    if kind=='two_coordinate':
        for hi,li,sh,sl in itertools.product(range(m),range(n),[-1.,1.],[-1.,1.]):
            u=np.zeros(d);u[hi]=sh*np.sqrt(r);u[m+li]=sl*np.sqrt(1-r)
            yield u,1/(4*m*n)
    else:
        w=np.r_[np.full(m,r/m),np.full(n,(1-r)/n)]
        for signs in itertools.product([-1.,1.],repeat=d):
            yield np.sqrt(w)*signs,1/(2**d)


def exact_policy_gain(m,n,r,q,H,coeff,kind):
    d=m+n;B=np.zeros((d,d));noise=0.
    for u,p in atoms(m,n,r,kind):
        aa=coeff*u;nn=aa@H@aa
        B+=p*(np.outer(u,aa)+np.outer(aa,u)-nn*np.outer(u,u))
        noise+=p*nn
    return float(np.linalg.eigvalsh(B)[0]-q*noise)


def main():
    source=json.loads((HERE/'same_covariance_variance.json').read_text())
    rng=np.random.default_rng(20260928);raw=rng.normal(size=(6,6));A=(raw+raw.T)/2
    A/=np.max(np.abs(np.linalg.eigvalsh(A)))
    rows=[]
    for case in source['cases']:
        if case['name']!='spiked_six' or case['r_fraction'] not in [.5,.75]:continue
        m,n,a,b,q,r=(case[k] for k in ['m','n','a','b','q','r'])
        h=np.r_[np.full(m,a),np.full(n,b)];H=np.diag(h);root=np.diag(np.sqrt(h));d=m+n
        prior=case['baseline']['H'];D=q+r*prior['zh']+(1-r)*prior['zl']
        original=np.r_[np.full(m,prior['zh']/a/D),np.full(n,prior['zl']/b/D)]
        ep=case['baseline']['I'];DE=q+r*ep['zh']+(1-r)*ep['zl']
        estimate=np.r_[np.full(m,ep['zh']/DE),np.full(n,ep['zl']/DE)]
        for eta in [.05,.1]:
            Hp=root@(np.eye(d)+eta*A)@root
            for kind in ['two_coordinate','dense']:
                value=exact_policy_gain(m,n,r,q,Hp,original/(1+eta),kind)
                estimation=exact_policy_gain(m,n,r,q,np.eye(d),estimate,kind)
                baseline=prior['value'];upper=baseline/(1-eta);factor=(1-eta)/(1+eta)
                rows.append(dict(r_fraction=case['r_fraction'],r=r,q=q,eta=eta,sampler=kind,
                                 noncommuting_H=Hp.tolist(),relative_perturbation_eigenvalues=np.linalg.eigvalsh(np.eye(d)+eta*A).tolist(),
                                 commutator_frobenius=float(np.linalg.norm(H@Hp-Hp@H)),
                                 original_exact_frontier_gain=baseline,transferred_policy_gain=value,
                                 transferred_policy_lower=baseline/(1+eta),
                                 estimation_gain=estimation,estimation_target=ep['value'],
                                 frontier_upper_from_Loewner=upper,
                                 policy_to_frontier_upper_ratio=value/upper,theorem_ratio_factor=factor,
                                 transfer_slack=value-baseline/(1+eta),ratio_slack=value/upper-factor))
    summary=dict(cases=len(rows),min_transfer_slack=min(r['transfer_slack'] for r in rows),
                 min_ratio_slack=min(r['ratio_slack'] for r in rows),
                 max_estimation_difference=max(abs(r['estimation_gain']-r['estimation_target']) for r in rows))
    assert summary['min_transfer_slack']>=-1e-12 and summary['min_ratio_slack']>=-1e-12
    assert summary['max_estimation_difference']<1e-12
    out=dict(summary=summary,perturbation_base=A.tolist(),rows=rows,
             scope='Floating-point matrix checks. Upper bound on perturbed frontier comes from the analytic Loewner transfer argument, not from solving the perturbed problem.')
    (HERE/'loewner_transfer.json').write_text(json.dumps(out,indent=2))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
