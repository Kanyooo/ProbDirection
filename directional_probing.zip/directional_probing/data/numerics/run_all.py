"""Portable entry point for the bounded scientific experiments."""
from pathlib import Path
import argparse
import os
import subprocess
import sys


HERE=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--quick',action='store_true',help='Run only the two structural experiments')
    args=ap.parse_args()
    commands=[('same_covariance_variance.py',[]),('loewner_transfer.py',[])]
    if not args.quick:
        commands += [('ogd/pair_ogd.py',['--adaptive','--symmetrize']),('ogd/run_exchange.py',[])]
        commands += [('ogd/audit_outputs.py',[])]
    env=os.environ.copy()
    env.setdefault('OPENBLAS_NUM_THREADS','1')
    env.setdefault('OMP_NUM_THREADS','1')
    for relative,options in commands:
        print('Running',relative,*options,flush=True)
        subprocess.run([sys.executable,str(HERE/relative),*options],cwd=HERE,env=env,check=True)


if __name__=='__main__':main()
