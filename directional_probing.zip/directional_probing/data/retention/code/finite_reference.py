"""Finite exact-arithmetic reference for specified-retention synthesis.

This deliberately conservative implementation follows the proved projected-OGD
and finite Frank--Wolfe schedules, rounding each iterate to a prescribed
simplex grid so that rational denominators do not accumulate across steps. It uses only the standard library and the
sibling exact_certificate.py. It is not a fast optimizer or a claim of favorable
bit complexity. Explicit work/bit limits abort before an uncertified result is
returned. A completed result is checked again through exact_certificate.

Example (small coarse nontrivial weighted game):
  python finite_reference.py --mode weighted --h 1,2 --q 1 --mu 1/4 --epsilon 4
Example (exact retention endpoint):
  python finite_reference.py --h 1,4 --q 1 --alpha 1 --epsilon 1/100
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from fractions import Fraction as F
import json
from pathlib import Path

import exact_certificate as ec


class WorkLimitError(RuntimeError):
    """Requested exact finite schedule exceeds the declared resource guard."""


@dataclass
class Budget:
    max_work: int = 20000
    max_fraction_bits: int = 20000
    used: int = 0

    def ensure(self, additional: int, stage: str):
        if self.used + additional > self.max_work:
            raise WorkLimitError(
                f'{stage}: proved schedule needs up to {additional} more '
                f'outer/FW steps, but {self.max_work-self.used} remain. '
                'No approximate or uncertified policy was returned.')

    def tick(self):
        self.ensure(1, 'iteration')
        self.used += 1

    def check_bits(self, values, stage: str):
        largest = max((max(abs(x.numerator).bit_length(), x.denominator.bit_length())
                       for x in values), default=0)
        if largest > self.max_fraction_bits:
            raise WorkLimitError(
                f'{stage}: rational size {largest} bits exceeds '
                f'max_fraction_bits={self.max_fraction_bits}. '
                'The arithmetic iteration bound is not a favorable bit bound; '
                'no uncertified result was returned.')


def ceil_fraction(x):
    x = ec.fraction(x)
    return -((-x.numerator) // x.denominator)


def project_simplex(values):
    """Exact Euclidean projection, including boundary and tied entries."""
    values = list(map(ec.fraction, values))
    ordered = sorted(values, reverse=True)
    partial = F(0)
    threshold = None
    for j, value in enumerate(ordered, 1):
        partial += value
        candidate = (partial - 1) / j
        if value > candidate:
            threshold = candidate
    if threshold is None:
        raise ArithmeticError('Simplex projection has no active coordinate')
    result = [max(F(0), value-threshold) for value in values]
    assert sum(result) == 1 and min(result) >= 0
    return result


def simplex_grid(values, denominator):
    """Largest-remainder rational simplex rounding, l1 error <= d/Q."""
    values=list(map(ec.fraction,values)); Q=int(denominator)
    assert Q>=1 and sum(values)==1 and min(values)>=0
    scaled=[Q*x for x in values]
    counts=[x.numerator//x.denominator for x in scaled]
    missing=Q-sum(counts)
    order=sorted(range(len(values)),key=lambda i:scaled[i]-counts[i],reverse=True)
    for i in order[:missing]: counts[i]+=1
    rounded=[F(n,Q) for n in counts]
    assert sum(rounded)==1 and min(rounded)>=0
    assert sum(abs(x-y) for x,y in zip(values,rounded))<=F(len(values),Q)
    return rounded


def constants(h, q):
    a = 1/min(h)
    b = 1/(4*q) if q <= 1 else 1/(1+q)**2
    return (a*(2/(1+q)+b), a*(3/q+F(8,27)/q**2))


def atom_value_sparse(z, W, h, q, indices=None):
    """At most two rational gradient entries for a pair atom."""
    if indices is None:
        indices = tuple(i for i, w in enumerate(W) if w)
    denominator = q + sum(z[i]*W[i] for i in indices)
    numerator = sum(z[i]**2*W[i]/h[i] for i in indices)
    sparse = [(i, W[i]*(2*z[i]/(h[i]*denominator)
                         - numerator/denominator**2)) for i in indices]
    return numerator/denominator, sparse


def atom_value_gradient(z, W, h, q):
    value, sparse = atom_value_sparse(z,W,h,q)
    gradient = [F(0)]*len(z)
    for i, component in sparse:
        gradient[i] = component
    return value, gradient


def empirical_law(history):
    counts = {}
    for W in history:
        key = tuple(W)
        counts[key] = counts.get(key, 0)+1
    # Cache pair support once. Every subsequent full-law gradient is O(N+d)
    # rational arithmetic, rather than looping over d coordinates per atom.
    return [(F(count,len(history)),list(W),tuple(i for i,w in enumerate(W) if w))
            for W,count in sorted(counts.items())]


def law_value_gradient(z, law, h, q):
    value = F(0)
    gradient = [F(0)]*len(z)
    for mass, W, indices in law:
        atom_value, sparse = atom_value_sparse(z,W,h,q,indices)
        value += mass*atom_value
        for i, component in sparse:
            gradient[i] += mass*component
    return value, gradient


def recover_prior(law, h, q, delta, budget):
    """Two finite FW phases, with sound optional earlier gap termination."""
    gradient_bound, smooth = constants(h,q)
    S = max(1,ceil_fraction(10*smooth/delta))
    grid = max(1,ceil_fraction(4*S*len(h)*gradient_bound/delta))
    rounding_error = gradient_bound*len(h)/grid
    budget.ensure(2*S, 'decoder recovery')
    z = [F(1,len(h))]*len(h)
    best = None
    evaluations = 0
    for phase in (1,2):
        for index in range(S):
            budget.tick(); evaluations += 1
            value, gradient = law_value_gradient(z,law,h,q)
            gap = sum(x*y for x,y in zip(z,gradient))-min(gradient)
            assert gap >= 0
            if best is None or gap < best['gap']:
                best = {'z':z.copy(),'value':value,'gap':gap}
            if gap <= delta:
                return {**best,'steps':evaluations,'phase_length_bound':S,
                        'smoothness_bound':smooth,'iterate_grid':grid,
                        'per_step_value_rounding_bound':rounding_error}
            coordinate = min(range(len(h)),key=gradient.__getitem__)
            step = F(2,index+2) if phase == 1 else F(1,S)
            z = [(1-step)*component for component in z]
            z[coordinate] += step
            z = simplex_grid(z,grid)
            budget.check_bits(z, 'rounded FW iterate')
    assert best is not None and best['gap'] <= delta
    return {**best,'steps':evaluations,'phase_length_bound':S,
            'smoothness_bound':smooth,'iterate_grid':grid,
                        'per_step_value_rounding_bound':rounding_error}


def policy_from_priors(law, zH, zI, h, q, zero_H=False, zero_I=False):
    policy = []
    for mass,W,indices in law:
        denH = q+sum(zH[i]*W[i] for i in indices)
        denI = q+sum(zI[i]*W[i] for i in indices)
        cH=[F(0)]*len(h); cI=[F(0)]*len(h)
        for i in indices:
            if not zero_H: cH[i]=zH[i]/(h[i]*denH)
            if not zero_I: cI[i]=zI[i]/denI
        policy.append({'p':mass,'W':W,'c_H':cH,'c_I':cI})
    return ec.merge_policy(policy)


def weighted_oracle(h, q, multiplier, eta, budget=None):
    """Return U>=C(mu), feasible gains, and U-h-mu*i<=eta, all exactly.

    Rational constants use initial radius <=1. With
    K=ceil(8(GH+mu GI)/eta), T=K^2, and steps 1/(Gk K), base regret
    is <=eta/8. A prescribed simplex grid adds <=eta/8. Pair error
    is eta/4 and bounded-grid FW recovery costs at most eta/2.
    """
    h = list(map(ec.fraction,h)); q=ec.fraction(q)
    mu,eta=ec.fraction(multiplier),ec.fraction(eta)
    if not h or min(h)<=0 or q<=0 or mu<0 or eta<=0:
        raise ValueError('Require positive spectrum, q, eta and nonnegative mu')
    budget = budget or Budget()
    start_work = budget.used
    d=len(h); ones=[F(1)]*d
    if len(set(h)) == 1:
        policy=ec.endpoint_policy(h,q); actual=ec.gains(policy,h,q)
        z=[F(1,d)]*d
        U=actual['H']['value']+mu*actual['I']['value']
        return {'policy':policy,'h':actual['H']['value'],'i':actual['I']['value'],
                'U':U,'multiplier':mu,'eta':eta,'gap':F(0),'outer_steps':0,
                'recovery_steps':0,'work_used':0,
                'dual':{'zH':z,'zI':z,'multiplier':mu,'upper':U,
                        'kind':'rational_pair_oracle'},'branch':'scalar_exact'}
    GH,LH=constants(h,q); GI,LI=constants(ones,q)
    K=max(1,ceil_fraction(8*(GH+mu*GI)/eta)); T=K*K
    iterate_grid=max(d,ceil_fraction(16*d*K*(GH+mu*GI)/eta))
    iterate_error=F(d,iterate_grid)
    delta=eta/(2*(1+mu)); rho=eta/4
    SH=max(1,ceil_fraction(10*LH/delta)); SI=max(1,ceil_fraction(10*LI/delta))
    budget.ensure(T+2*SH+2*SI, 'weighted oracle')
    stepH,stepI=1/(GH*K),1/(GI*K)
    zH=[F(1,d)]*d; zI=zH.copy()
    best=None; history=[]; pair_bisections=0
    for _ in range(T):
        budget.tick()
        bracket=ec.pair_upper(h,q,zH,zI,mu,rho)
        W=bracket['W']
        valueH,gH=atom_value_gradient(zH,W,h,q)
        valueI,gI=atom_value_gradient(zI,W,ones,q)
        assert bracket['lower'] == valueH+mu*valueI
        assert F(0)<=bracket['upper']-bracket['lower']<=rho
        pair_bisections += bracket['bisection_steps']
        if best is None or bracket['upper']<best['upper']:
            best={'kind':'rational_pair_oracle','zH':zH.copy(),'zI':zI.copy(),
                  'multiplier':mu,'upper':bracket['upper'],
                  'pair_tolerance':rho}
        history.append(W)
        zH=simplex_grid(project_simplex([z-stepH*g for z,g in zip(zH,gH)]),iterate_grid)
        zI=simplex_grid(project_simplex([z-stepI*g for z,g in zip(zI,gI)]),iterate_grid)
        budget.check_bits(zH+zI, 'rounded projected OGD iterate')
    law=empirical_law(history)
    recH=recover_prior(law,h,q,delta,budget)
    recI=recover_prior(law,ones,q,delta,budget)
    lowerH=recH['value']-recH['gap']; lowerI=recI['value']-recI['gap']
    policy=policy_from_priors(law,recH['z'],recI['z'],h,q,
                              zero_H=lowerH<0,zero_I=lowerI<0)
    actual=ec.gains(policy,h,q); Hgain=actual['H']['value']; Igain=actual['I']['value']
    assert Hgain==max(F(0),lowerH) and Igain==max(F(0),lowerI)
    U=best['upper']; gap=U-Hgain-mu*Igain
    assert F(0)<=gap<=eta
    assert (GH+mu*GI)/K<=eta/8
    rounding_regret=2*iterate_error*K*(GH+mu*GI)
    assert rounding_regret<=eta/8
    return {'policy':policy,'h':Hgain,'i':Igain,'U':U,'multiplier':mu,
            'eta':eta,'gap':gap,'dual':best,'outer_steps':T,
            'outer_base_regret_bound':(GH+mu*GI)/K,
            'outer_rounding_regret_bound':rounding_regret,
            'outer_regret_bound':(GH+mu*GI)/K+rounding_regret,
            'iterate_grid':iterate_grid,'pair_error_budget':rho,
            'recovery_error_bound':recH['gap']+mu*recI['gap'],
            'recovery_steps':recH['steps']+recI['steps'],
            'recovery_H':recH,'recovery_I':recI,'K':K,
            'pair_bisections':pair_bisections,'work_used':budget.used-start_work,
            'branch':'finite_projected_ogd'}


def _retention_result(policy,h,q,alpha,epsilon,upper,witness,branch,records,budget):
    policy=ec.merge_policy(policy); actual=ec.gains(policy,h,q)
    d=len(h); istar=F(1)/(d*(1+d*q)); target=alpha*istar
    lower=actual['H']['value']; slack=actual['I']['value']-target
    assert slack>=0 and F(0)<=upper-lower<=epsilon
    return {'h':h,'q':q,'alpha':alpha,'epsilon':epsilon,'Istar':istar,
            'target_I':target,'policy':policy,'actual_gain_H':lower,
            'actual_gain_I':actual['I']['value'],'feasibility_slack':slack,
            'optimality_upper':upper,'optimality_gap':upper-lower,
            'upper_witness':witness,'weighted_calls':records,'branch':branch,
            'work_used':budget.used,'max_work':budget.max_work,
            'max_fraction_bits':budget.max_fraction_bits,
            'amplitude_atoms':len(policy),'literal_direction_atoms_upper':4*len(policy),
            'arithmetic':'exact fractions with prescribed bounded-grid simplex iterates',
            'decoder_observation':'u and Y only; c is a deterministic function of W=u^2',
            'response_scope':'all measurable' if q>=F(1,3) else 'linear only'}


def finite_retention(h,q,alpha,epsilon,budget=None,endpoint_shortcut=True):
    """The finite multiplier algorithm, with exact observation-only mixtures."""
    h=list(map(ec.fraction,h)); q=ec.fraction(q)
    alpha,epsilon=ec.fraction(alpha),ec.fraction(epsilon)
    if not h or min(h)<=0 or q<=0 or not 0<=alpha<=1 or epsilon<=0:
        raise ValueError('Invalid specified-retention problem')
    budget=budget or Budget()
    d=len(h); istar=F(1)/(d*(1+d*q)); target=alpha*istar
    hE=F(1)/(sum(h)*(1+d*q)); endpoint=ec.endpoint_policy(h,q)
    k2=ec.endpoint_modulus_squared(h,q)
    if alpha==1 or k2==0:
        return _retention_result(endpoint,h,q,alpha,epsilon,hE,
            {'kind':'endpoint_modulus','K_squared':k2},'exact_endpoint',[],budget)
    if endpoint_shortcut and k2*(1-alpha)<=epsilon**2:
        increment=min(epsilon,ec.sqrt_upper(k2*(1-alpha),epsilon/64))
        return _retention_result(endpoint,h,q,alpha,epsilon,hE+increment,
            {'kind':'endpoint_modulus','K_squared':k2},'endpoint_modulus',[],budget)
    eta=epsilon/2; records=[]; best=None

    def call(mu):
        nonlocal best
        out=weighted_oracle(h,q,mu,eta,budget)
        records.append({key:out[key] for key in
                        ('multiplier','eta','U','h','i','gap','outer_steps',
                         'recovery_steps','work_used','branch')})
        constrained=out['U']-mu*target
        if best is None or constrained<best[0]:
            best=(constrained,out['dual'])
        return out

    low=call(F(0))
    if low['i']>=target:
        return _retention_result(low['policy'],h,q,alpha,epsilon,*best,
                                 'zero_multiplier_feasible',records,budget)
    # A computed zero-multiplier upper can also certify the exact endpoint.
    if best[0]-hE<=epsilon:
        return _retention_result(endpoint,h,q,alpha,epsilon,*best,
                                 'endpoint_from_global_upper',records,budget)
    Delta=istar-target
    Lambda=(low['U']-hE+2*eta)/Delta
    high=call(Lambda)
    assert high['i']>=target+eta/Lambda
    midpoint_calls=0
    width_bound=Lambda
    maximum_midpoints=0
    while width_bound>2*epsilon/istar:
        maximum_midpoints+=1; width_bound/=2
    while True:
        assert low['i']<target<=high['i']
        beta=(target-low['i'])/(high['i']-low['i'])
        policy=ec.mix([low['policy'],high['policy']],[1-beta,beta])
        actual=ec.gains(policy,h,q)
        assert actual['I']['value']>=target
        width=high['multiplier']-low['multiplier']
        assert best[0]-actual['H']['value']<=eta+istar*width/4
        if best[0]-actual['H']['value']<=epsilon:
            result=_retention_result(policy,h,q,alpha,epsilon,*best,
                                      'multiplier_bisection',records,budget)
            result.update(Lambda=Lambda,midpoint_calls=midpoint_calls,
                          midpoint_call_bound=maximum_midpoints,
                          bracket_width=width,high_weight=beta)
            return result
        assert midpoint_calls<maximum_midpoints
        middle=call((low['multiplier']+high['multiplier'])/2)
        midpoint_calls+=1
        if middle['i']>=target: high=middle
        else: low=middle


def self_test():
    """Short exact checks; does not pretend to run demanding fine schedules."""
    assert project_simplex([F(-1),F(2)])==[F(0),F(1)]
    assert project_simplex([F(1,4),F(1,4)])==[F(1,2),F(1,2)]
    out=weighted_oracle([1,2],F(1),F(1,4),F(4),Budget(2000,20000))
    assert out['branch']=='finite_projected_ogd' and out['outer_steps']>=1
    assert F(0)<=out['gap']<=4
    actual=ec.gains(out['policy'],[F(1),F(2)],F(1))
    assert actual['H']['value']==out['h'] and actual['I']['value']==out['i']
    assert out['h']>0 and out['i']>0
    endpoint=finite_retention([1,4],1,1,F(1,100),Budget(1000))
    near=finite_retention([1,4],1,F(999,1000),F(1,100),Budget(1000))
    assert endpoint['optimality_gap']==0 and near['optimality_gap']<=F(1,100)
    try:
        weighted_oracle([1,4],1,1,F(1,1000),Budget(2))
    except WorkLimitError:
        guarded=True
    else:
        raise AssertionError('Work guard failed to reject a huge finite schedule')
    return {'passed':True,'weighted_outer_steps':out['outer_steps'],
            'weighted_recovery_steps':out['recovery_steps'],
            'weighted_exact_gap':out['gap'],'weighted_gain_H':out['h'],
            'weighted_gain_I':out['i'],'endpoint_gap':endpoint['optimality_gap'],
            'near_endpoint_gap':near['optimality_gap'],'large_schedule_aborted':guarded,
            'scope':'bounded-grid exact schedule and endpoint tests; no fine large schedule run'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode',choices=['retention','weighted','self-test'],default='retention')
    parser.add_argument('--h',default='1,4')
    parser.add_argument('--q',default='1')
    parser.add_argument('--alpha',default='1')
    parser.add_argument('--mu',default='1/4')
    parser.add_argument('--epsilon',default='1/100')
    parser.add_argument('--max-work',type=int,default=20000)
    parser.add_argument('--max-fraction-bits',type=int,default=20000)
    parser.add_argument('--no-endpoint-shortcut',action='store_true')
    parser.add_argument('--out',type=Path)
    args=parser.parse_args()
    try:
        if args.mode=='self-test': result=self_test()
        else:
            budget=Budget(args.max_work,args.max_fraction_bits)
            h=[ec.fraction(x.strip()) for x in args.h.split(',')]
            if args.mode=='weighted':
                result=weighted_oracle(h,args.q,args.mu,args.epsilon,budget)
            else:
                result=finite_retention(h,args.q,args.alpha,args.epsilon,budget,
                                        endpoint_shortcut=not args.no_endpoint_shortcut)
        encoded=json.dumps(ec.jsonable(result),indent=2)
        if args.out:
            args.out.parent.mkdir(parents=True,exist_ok=True)
            args.out.write_text(encoded+'\n')
            if args.mode=='retention': ec.verify_saved(args.out)
        print(encoded)
    except WorkLimitError as error:
        print(json.dumps({'completed':False,'reason':'explicit_work_or_bit_limit',
                          'message':str(error)},indent=2))
        raise SystemExit(2)


if __name__=='__main__':
    main()
