"""Exact rational certificates for specified-retention probe synthesis.

Only the Python standard library is needed. A policy is a finite law of
squared amplitudes W, followed by independent signs; its task responses are
a_i(u)=c_i(W)*u_i. Duplicate W atoms are merged by conditional averaging,
so neither decoder uses the sampled component label.

Floating-point optimizers only propose candidates. Feasibility and the
global upper bracket below are recomputed with fractions.Fraction.
"""
from __future__ import annotations

from fractions import Fraction as F
import json
from pathlib import Path
from typing import Any


def fraction(x: Any) -> F:
    return x if isinstance(x, F) else F(str(x))


def snap(x: Any, grid: int = 10**12) -> F:
    x = fraction(x)
    return F((x * grid + F(1, 2)).numerator // (x * grid + F(1, 2)).denominator, grid)


def simplex(values, grid: int = 10**12):
    if not isinstance(grid,int) or grid < 1:
        raise ValueError('Grid denominator must be a positive integer')
    values = [max(F(0), fraction(x)) for x in values]
    total = sum(values)
    if total <= 0:
        raise ValueError('Simplex candidate has no positive mass')
    integers, remainders = [], []
    for value in values:
        scaled = value / total * grid
        integer = scaled.numerator // scaled.denominator
        integers.append(integer)
        remainders.append(scaled-integer)
    remainder_count = grid-sum(integers)
    order = sorted(range(len(integers)),key=lambda i:(-remainders[i],i))
    for i in order[:remainder_count]:
        integers[i] += 1
    return [F(x, grid) for x in integers]


def merge_policy(policy):
    """Return marginal atoms and E[c | W], not label-indexed decoders."""
    grouped = {}
    for atom in policy:
        p = fraction(atom['p'])
        if p == 0:
            continue
        if p < 0:
            raise ValueError('Negative policy probability')
        w = tuple(fraction(x) for x in atom['W'])
        if not w or len(atom['c_H']) != len(w) or len(atom['c_I']) != len(w):
            raise ValueError('Amplitude and decoder dimensions must agree')
        if min(w) < 0 or sum(w) != 1:
            raise ValueError('Invalid amplitude simplex atom')
        if sum(x > 0 for x in w) > 2:
            raise ValueError('Policy is not pair-supported')
        if w not in grouped:
            grouped[w] = {'p': F(0), 'H': [F(0)] * len(w), 'I': [F(0)] * len(w)}
        rec = grouped[w]
        rec['p'] += p
        for task in ('H', 'I'):
            for i, value in enumerate(atom['c_' + task]):
                # Inactive coordinates never affect the response.
                rec[task][i] += p * fraction(value) if w[i] else F(0)
    result = []
    for w, rec in sorted(grouped.items()):
        p = rec['p']
        result.append({'p': p, 'W': list(w),
                       'c_H': [x / p for x in rec['H']],
                       'c_I': [x / p for x in rec['I']]})
    if sum(a['p'] for a in result) != 1:
        raise ValueError('Policy probabilities must sum exactly to one')
    return result


def rationalize_policy(policy, grid: int = 10**12):
    pp = simplex([a['p'] for a in policy], grid)
    atoms = []
    for p, atom in zip(pp, policy):
        if p:
            atoms.append({'p': p, 'W': simplex(atom['W'], grid),
                          'c_H': [snap(c, grid) for c in atom['c_H']],
                          'c_I': [snap(c, grid) for c in atom['c_I']]})
    return merge_policy(atoms)


def gain(policy, diagonal, q):
    diagonal = [fraction(a) for a in diagonal]
    q = fraction(q)
    d = len(diagonal)
    task = 'I' if all(a == 1 for a in diagonal) else 'H'
    return task_gain(policy, diagonal, q, task)


def task_gain(policy, diagonal, q, task):
    diagonal = [fraction(a) for a in diagonal]
    q = fraction(q)
    d = len(diagonal)
    if not diagonal or min(diagonal) <= 0 or q <= 0 or task not in ('H','I'):
        raise ValueError('Invalid task parameters')
    B = [F(0)] * d
    N = F(0)
    for atom in policy:
        p, w, c = atom['p'], atom['W'], atom['c_' + task]
        if len(w) != d or len(c) != d:
            raise ValueError('Policy dimension does not match the task')
        nn = sum(diagonal[i] * c[i]**2 * w[i] for i in range(d))
        N += p * nn
        for i in range(d):
            B[i] += p * w[i] * (2 * c[i] - nn)
    return {'value': min(B) - q * N, 'B': B, 'N': N}


def gains(policy, h, q):
    return {'H': task_gain(policy, h, q, 'H'),
            'I': task_gain(policy, [1] * len(h), q, 'I')}


def mix(policies, weights):
    weights = [fraction(w) for w in weights]
    if sum(weights) != 1 or min(weights) < 0:
        raise ValueError('Invalid mixing weights')
    atoms = []
    for policy, weight in zip(policies, weights):
        for atom in policy:
            atoms.append({**atom, 'p': weight * atom['p']})
    return merge_policy(atoms)


def endpoint_policy(h, q):
    """At most d pair atoms: isotropy and constant directional curvature."""
    h, q = [fraction(x) for x in h], fraction(q)
    if not h or min(h) <= 0 or q <= 0:
        raise ValueError('Positive spectrum and positive noise are required')
    d = len(h)
    A = sum(h)
    mean = A / d
    lo = [[i, (mean - x) / d] for i, x in enumerate(h) if x < mean]
    hi = [[i, (x - mean) / d] for i, x in enumerate(h) if x > mean]
    base = {'c_I': [1 / (1 + d*q)] * d,
            'c_H': [F(d) / (A * (1 + d*q))] * d}
    result = []
    for i, x in enumerate(h):
        if x == mean:
            w = [F(0)] * d; w[i] = F(1)
            result.append({**base, 'p': F(1, d), 'W': w})
    left = right = 0
    while left < len(lo) and right < len(hi):
        i, mass_i = lo[left]; j, mass_j = hi[right]
        transported = min(mass_i, mass_j)
        dl, dh = mean - h[i], h[j] - mean
        w = [F(0)] * d
        w[i], w[j] = dh / (dl + dh), dl / (dl + dh)
        result.append({**base, 'p': transported * (1/dl + 1/dh), 'W': w})
        lo[left][1] -= transported; hi[right][1] -= transported
        if lo[left][1] == 0: left += 1
        if hi[right][1] == 0: right += 1
    result = merge_policy(result)
    stats = gains(result, h, q)
    assert len(result) <= d
    assert stats['I']['value'] == F(1) / (d * (1 + d*q))
    assert stats['H']['value'] == F(1) / (A * (1 + d*q))
    for atom in result:
        assert sum(x*y for x,y in zip(h,atom['W'])) == mean
    for i in range(d):
        assert sum(a['p'] * a['W'][i] for a in result) == F(1,d)
    return result


def repair(policy, h, q, alpha):
    """Restore exact retention after any rationalization, without labels."""
    h, q, alpha = [fraction(x) for x in h], fraction(q), fraction(alpha)
    d = len(h); istar = F(1) / (d * (1 + d*q)); target = alpha * istar
    endpoint = endpoint_policy(h, q)
    old = gains(policy, h, q)
    if old['I']['value'] >= target:
        return policy, F(0)
    if alpha == 1:
        return endpoint, F(1)
    theta = (target - old['I']['value']) / (istar - old['I']['value'])
    result = mix([policy, endpoint], [1-theta, theta])
    assert gains(result, h, q)['I']['value'] >= target
    return result, theta


def endpoint_modulus_squared(h, q):
    h, q = [fraction(x) for x in h], fraction(q)
    d = len(h); A = sum(h); variance = sum((x - A/d)**2 for x in h)
    return F(4*d**3) * q * variance / (A**4 * (1+2*d*q)**2 * (1+d*q))


def sqrt_upper(x, tolerance=F(1,10**12)):
    x, tolerance = fraction(x), fraction(tolerance)
    if x < 0 or tolerance <= 0: raise ValueError('Invalid square-root bound')
    if x == 0: return F(0)
    low, high = F(0), max(F(1), x)
    while high - low > tolerance:
        mid = (low + high) / 2
        if mid*mid >= x: high = mid
        else: low = mid
    return high


def pair_upper(h, q, zH, zI, multiplier, tolerance):
    """Rational global upper bound for h+multiplier*i support value.

    On each edge, at most one isolated stationary point can occur. If its
    endpoint derivatives go from positive to negative, isolate that maximum
    by rational bisection. The sum of the two individual endpoint maxima on
    the remaining bracket is a rigorous upper bound. Other edges attain a
    maximum at an endpoint. No polynomial-root floating arithmetic is used.
    """
    h, q = [fraction(x) for x in h], fraction(q)
    zH, zI = [fraction(x) for x in zH], [fraction(x) for x in zI]
    mu, tolerance = fraction(multiplier), fraction(tolerance)
    d = len(h)
    if min(h) <= 0 or q <= 0 or mu < 0 or tolerance <= 0:
        raise ValueError('Invalid dual-certificate parameters')
    for z in (zH,zI):
        if len(z) != d or min(z) < 0 or sum(z) != 1:
            raise ValueError('Dual prior must be exactly a simplex point')
    vertex = [zH[i]**2 / (h[i]*(q+zH[i])) + mu*zI[i]**2/(q+zI[i])
              for i in range(d)]
    upper = lower = max(vertex)
    best_vertex = max(range(d),key=vertex.__getitem__)
    best_W = [F(0)]*d; best_W[best_vertex] = F(1)
    total_steps = 0; stationary_edges = 0
    for i in range(d):
        for j in range(i+1,d):
            nH0 = zH[j]**2 / h[j]; nHd = zH[i]**2/h[i] - nH0
            dH0 = q + zH[j]; dHd = zH[i] - zH[j]
            nI0 = mu*zI[j]**2; nId = mu*zI[i]**2 - nI0
            dI0 = q + zI[j]; dId = zI[i] - zI[j]
            kH = nHd*dH0 - nH0*dHd; kI = nId*dI0 - nI0*dId
            def values(t):
                return ((nH0+nHd*t)/(dH0+dHd*t),
                        (nI0+nId*t)/(dI0+dId*t))
            def derivative(t):
                return kH/(dH0+dHd*t)**2 + kI/(dI0+dId*t)**2
            edge_upper = edge_lower = max(vertex[i],vertex[j])
            edge_t = F(1) if vertex[i] >= vertex[j] else F(0)
            if derivative(F(0)) > 0 and derivative(F(1)) < 0:
                stationary_edges += 1
                left, right = F(0), F(1)
                while True:
                    vl, vr = values(left), values(right)
                    edge_upper = max(vl[0],vr[0]) + max(vl[1],vr[1])
                    edge_lower = max(sum(vl),sum(vr))
                    edge_t = left if sum(vl) >= sum(vr) else right
                    if edge_upper-edge_lower <= tolerance:
                        break
                    mid = (left+right)/2; slope = derivative(mid)
                    total_steps += 1
                    if slope == 0:
                        edge_upper = edge_lower = sum(values(mid)); edge_t = mid; break
                    if slope > 0: left = mid
                    else: right = mid
            upper = max(upper,edge_upper)
            if edge_lower > lower:
                lower = edge_lower
                best_W = [F(0)]*d
                best_W[i],best_W[j] = edge_t,1-edge_t
    assert upper-lower <= tolerance
    return {'upper': upper, 'lower': lower, 'W':best_W, 'oracle_width': upper-lower,
            'bisection_steps': total_steps, 'stationary_edges': stationary_edges}


def certify(policy, h, q, alpha, epsilon, dual_candidates=(), grid=10**12,
            already_rational=False):
    """Return a proof-carrying rational policy; reject if the gap is too big."""
    h = [fraction(x) for x in h]
    q, alpha, epsilon = fraction(q), fraction(alpha), fraction(epsilon)
    if not 0 <= alpha <= 1 or epsilon <= 0:
        raise ValueError('Require alpha in [0,1] and epsilon > 0')
    d = len(h); Istar = F(1)/(d*(1+d*q)); target = alpha*Istar
    endpoint = endpoint_policy(h,q)
    hE = F(1)/(sum(h)*(1+d*q))
    k2 = endpoint_modulus_squared(h,q)
    shortcut = k2*(1-alpha) <= epsilon**2
    if shortcut:
        policy = endpoint
        repair_weight = F(0)
    else:
        policy = merge_policy(policy) if already_rational else rationalize_policy(policy,grid)
        policy, repair_weight = repair(policy,h,q,alpha)
    actual = gains(policy,h,q)
    endpoint_upper = hE + sqrt_upper(k2*(1-alpha),epsilon/F(64))
    # Exact squared comparison certifies shortcut without square-root rounding.
    if shortcut:
        endpoint_upper = min(endpoint_upper,hE+epsilon)
    upper = endpoint_upper; witness = {'kind':'endpoint_modulus','K_squared':k2}
    dual_records = []
    for candidate in dual_candidates:
        mu = max(F(0),fraction(candidate['multiplier']))
        zH = simplex(candidate['zH'],grid); zI = simplex(candidate['zI'],grid)
        bracket = pair_upper(h,q,zH,zI,mu,epsilon/F(64))
        constrained_upper = bracket['upper'] - mu*target
        record = {**bracket,'multiplier':mu,'zH':zH,'zI':zI,
                  'constrained_upper':constrained_upper}
        dual_records.append(record)
        if constrained_upper < upper:
            upper = constrained_upper
            witness = {'kind':'rational_pair_oracle',**record}
    lower = actual['H']['value']; feasibility = actual['I']['value']-target
    if feasibility < 0 or upper < lower:
        raise ArithmeticError('Invalid exact feasibility/optimality bracket')
    gap = upper-lower
    if gap > epsilon:
        raise ValueError(f'Candidate not certified: gap={float(gap):.6g}, eps={float(epsilon):.6g}')
    return {'h':h,'q':q,'alpha':alpha,'epsilon':epsilon,'Istar':Istar,
            'target_I':target,'policy':policy,'actual_gain_H':lower,
            'actual_gain_I':actual['I']['value'],'feasibility_slack':feasibility,
            'optimality_upper':upper,'optimality_gap':gap,'upper_witness':witness,
            'dual_candidates':dual_records,'repair_weight':repair_weight,
            'endpoint_shortcut':shortcut,'amplitude_atoms':len(policy),
            'literal_direction_atoms_upper':4*len(policy),
            'grid_denominator':grid,'arithmetic':'exact rational',
            'decoder_observation':'u and Y only; c is a deterministic function of W=u^2',
            'response_scope':'all measurable' if q >= F(1,3) else 'linear only'}


def jsonable(value):
    if isinstance(value,F): return str(value)
    if isinstance(value,dict): return {k:jsonable(v) for k,v in value.items()}
    if isinstance(value,(list,tuple)): return [jsonable(v) for v in value]
    return value


def verify_saved(path):
    """Independently recompute every asserted bound from a saved certificate."""
    def require(condition, message):
        # Certificate validation must remain active under python -O.
        if not condition:
            raise ValueError(message)
    raw=json.loads(Path(path).read_text())
    h,q=[fraction(x) for x in raw['h']],fraction(raw['q'])
    alpha,epsilon=fraction(raw['alpha']),fraction(raw['epsilon'])
    if not h or min(h)<=0 or q<=0 or not 0<=alpha<=1 or epsilon<=0:
        raise ValueError('Invalid certificate problem parameters')
    policy=[{'p':fraction(a['p']),'W':[fraction(x) for x in a['W']],
             'c_H':[fraction(x) for x in a['c_H']],
             'c_I':[fraction(x) for x in a['c_I']]} for a in raw['policy']]
    policy=merge_policy(policy);actual=gains(policy,h,q)
    target=alpha/(len(h)*(1+len(h)*q))
    require(fraction(raw['Istar'])==F(1)/(len(h)*(1+len(h)*q)), 'Incorrect Istar')
    require(fraction(raw['target_I'])==target, 'Incorrect retention target')
    require(actual['I']['value']>=target, 'Returned policy is infeasible')
    require(actual['I']['value']==fraction(raw['actual_gain_I']), 'Incorrect estimation gain')
    require(actual['H']['value']==fraction(raw['actual_gain_H']), 'Incorrect progress gain')
    upper=fraction(raw['optimality_upper']);w=raw['upper_witness']
    if w['kind']=='endpoint_modulus':
        hE=F(1)/(sum(h)*(1+len(h)*q))
        k2=endpoint_modulus_squared(h,q)
        require(upper>=hE and (upper-hE)**2>=k2*(1-alpha), 'Invalid endpoint upper bound')
    elif w['kind']=='rational_pair_oracle':
        bracket=pair_upper(h,q,w['zH'],w['zI'],w['multiplier'],epsilon/F(64))
        require(upper>=bracket['upper']-fraction(w['multiplier'])*target, 'Invalid dual upper bound')
    else: raise ValueError('Unrecognized upper-bound witness')
    require(F(0)<=upper-actual['H']['value']<=epsilon, 'Optimality gap exceeds requested tolerance')
    require(fraction(raw['optimality_gap'])==upper-actual['H']['value'], 'Incorrect reported gap')
    require(fraction(raw['feasibility_slack'])==actual['I']['value']-target, 'Incorrect feasibility slack')
    require(raw['response_scope']==('all measurable' if q>=F(1,3) else 'linear only'), 'Incorrect response scope')
    require(raw['amplitude_atoms']==len(policy), 'Incorrect amplitude count')
    require(raw['literal_direction_atoms_upper']==4*len(policy), 'Incorrect direction count')
    return {'passed':True,'atoms':len(policy),'gap':float(upper-actual['H']['value']),
            'feasibility_slack':float(actual['I']['value']-target)}


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate',type=Path)
    args=parser.parse_args()
    print(json.dumps(verify_saved(args.certificate),indent=2))
