"""Finite shared-measurement design at a prescribed estimation retention.

Public entry point: solve_retention(h, q, alpha, epsilon).
Units: J_I=1-MSE/G^2 and J_H=2*expected quadratic decrease/G^2; epsilon is
ABSOLUTE J_H error. Coefficients implement s_A(u,Y)=c_A(u**2)*u*Y and never
receive an acquisition-component label. Sampling uses independent signs.

solve_retention_candidate returns FLOATING-POINT CANDIDATES only. The default
solve_retention wrapper accepts a candidate only after the separate standard-
library exact_certificate module proves feasibility and the global gap using
rational arithmetic. Raw candidates are retained as numerical diagnostics.

Dependencies: NumPy, SciPy, CVXPY, and CLARABEL (CVXPY is imported lazily).
The positive-denominator pair oracle avoids coefficient truncation/np.roots.
No files outside this module's directory are imported or modified.
"""
from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
import time
import warnings
from fractions import Fraction

import numpy as np
from scipy.optimize import brentq, minimize


def jsonable(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, (np.floating, np.integer, np.bool_)): return x.item()
    if isinstance(x, dict): return {k:jsonable(v) for k,v in x.items()}
    if isinstance(x, (tuple,list)): return [jsonable(v) for v in x]
    return x


def project_simplex(v):
    v=np.asarray(v,float)
    ordered=np.sort(v)[::-1]; cumulative=np.cumsum(ordered)-1
    rho=np.flatnonzero(ordered-cumulative/np.arange(1,len(v)+1)>0)[-1]
    p=np.maximum(v-cumulative[rho]/(rho+1),0.)
    return p/p.sum()


def spectral_optimum(h,q):
    h=np.asarray(h,float); scale=h.sum(); hh=h/scale
    root=brentq(lambda t:np.sum((t*hh+np.sqrt(t*t*hh*hh+4*q*t*hh))/2)-1,
                0.,1.,xtol=5e-15)
    value=root/scale
    z=(value*h+np.sqrt(value*value*h*h+4*q*value*h))/2
    z=project_simplex(z)
    S=np.sum(z/(z+2*q)); D=1-q*S
    p=z*(z+q)/(D*(z+2*q));p/=p.sum()
    return dict(value=float(value),prior=z,coordinate_probabilities=p)


def task_fraction(W,z,h,q):
    return (W@(z*z/h))/(q+W@z)


def pair_oracle(z,x,h,q,weights=(1.,1.)):
    """All vertices and the possible interior stationary point on every edge.

    Denominators are positive. Opposite derivative signs reduce the stationary
    equation to a LINEAR equation after positive square roots. This is still
    floating arithmetic; an independent certifier must bound rounding errors.
    """
    z=np.asarray(z,float);x=np.asarray(x,float);h=np.asarray(h,float)
    co,ce=weights;d=len(h);A=z*z/h;C=x*x
    candidates=[]
    if d==1:
        W=np.ones(1);return float(co*task_fraction(W,z,h,q)+ce*task_fraction(W,x,np.ones(d),q)),W,[(0.,W)]
    for i,j in itertools.combinations(range(d),2):
        a0,da=A[j],A[i]-A[j];b0,db=q+z[j],z[i]-z[j]
        c0,dc=C[j],C[i]-C[j];d0,dd=q+x[j],x[i]-x[j]
        ko=co*(da*b0-a0*db);ke=ce*(dc*d0-c0*dd)
        ts=[0.,1.]
        if (ko>0 and ke<0) or (ko<0 and ke>0):
            sk,se=math.sqrt(abs(ko)),math.sqrt(abs(ke))
            den=sk*dd-se*db
            if den!=0:
                t=(se*b0-sk*d0)/den
                if 0<t<1:ts.append(float(t))
        for t in ts:
            w=np.zeros(d);w[i]=t;w[j]=1-t
            val=co*task_fraction(w,z,h,q)+ce*task_fraction(w,x,np.ones(d),q)
            candidates.append((float(val),w))
    candidates.sort(key=lambda v:v[0],reverse=True)
    return candidates[0][0],candidates[0][1],candidates


def actual_gain(W,p,c,h,q):
    """Exact-form diagonal gain matrix under independent coordinate signs."""
    W=np.asarray(W,float);p=np.asarray(p,float);c=np.asarray(c,float);h=np.asarray(h,float)
    energy=np.sum(W*c*c*h[None,:],axis=1)
    B=np.sum(p[:,None]*W*(2*c-energy[:,None]),axis=0)
    noise=float(q*(p@energy));K=B-noise
    return dict(gain=float(np.min(K)),matrix_diagonal=K,signal_diagonal=B,
                noise_penalty=noise,noise_energy=float(p@energy))


def policy_metrics(policy,h,q):
    return dict(H=actual_gain(policy['W'],policy['p'],policy['c_H'],h,q),
                I=actual_gain(policy['W'],policy['p'],policy['c_I'],np.ones(len(h)),q))


def collapse_policy(W,p,c_H,c_I,h,q):
    """Collapse EXACTLY repeated amplitudes by conditional coefficient means.

    Nearby but unequal amplitudes are not merged: doing so changes the law.
    This is averaging actual response coefficients, not averaging priors.
    """
    W=np.maximum(np.asarray(W,float),0.);W=W/W.sum(axis=1)[:,None]
    p=np.maximum(np.asarray(p,float),0.);p=p/p.sum()
    c_H=np.asarray(c_H,float);c_I=np.asarray(c_I,float)
    groups={}
    for w,mass,ch,ci in zip(W,p,c_H,c_I):
        if mass==0:continue
        key=tuple(w)
        if key not in groups:groups[key]=[0.,np.zeros(len(h)),np.zeros(len(h))]
        groups[key][0]+=mass;groups[key][1]+=mass*ch;groups[key][2]+=mass*ci
    ww=[];pp=[];ch=[];ci=[]
    for key,(mass,ah,ai) in groups.items():
        ww.append(key);pp.append(mass);ch.append(ah/mass);ci.append(ai/mass)
    out=dict(W=np.asarray(ww),p=np.asarray(pp),c_H=np.asarray(ch),c_I=np.asarray(ci),
             sampling='Choose an amplitude row using p, then independent Rademacher signs on its nonzero coordinates.',
             decoder_rule='For the observed u, find W=u**2 and return c_A(W)*u*Y. No component label is supplied.',
             label_free=True)
    out['p']/=out['p'].sum();out['metrics']=policy_metrics(out,h,q)
    out['amplitude_atoms']=len(out['p'])
    out['max_probe_support']=int(np.max(np.count_nonzero(out['W'],axis=1)))
    return out


def recover_task(W,p,h,q):
    W=np.asarray(W,float);p=np.asarray(p,float);h=np.asarray(h,float);d=len(h)
    def fg(z):
        den=q+W@z;num=W@(z*z/h)
        val=float(p@(num/den))
        grad=np.sum(p[:,None]*(2*W*z/h/den[:,None]-W*(num/den**2)[:,None]),axis=0)
        return val,grad
    scale=1/max(spectral_optimum(h,q)['value'],np.finfo(float).tiny)
    res=minimize(lambda z:scale*fg(z)[0],np.ones(d)/d,
                 jac=lambda z:scale*fg(z)[1],method='SLSQP',bounds=[(0.,1.)]*d,
                 constraints=[dict(type='eq',fun=lambda z:z.sum()-1,jac=lambda z:np.ones(d))],
                 options=dict(ftol=2e-13,maxiter=1500))
    z=project_simplex(res.x);val,grad=fg(z)
    c=z[None,:]/h[None,:]/(q+W@z)[:,None]
    metrics=actual_gain(W,p,c,h,q);zero_fallback=False
    if metrics['gain']<0:
        c=np.zeros_like(c);metrics=actual_gain(W,p,c,h,q);zero_fallback=True
    return dict(prior=z,coefficients=c,metrics=metrics,prior_objective=val,
                fw_residual=float(max(0.,z@grad-grad.min())),
                solver_success=bool(res.success),solver_message=str(res.message),
                zero_response_fallback=zero_fallback)


def fit_policy(W,p,h,q):
    H=recover_task(W,p,h,q);I=recover_task(W,p,np.ones(len(h)),q)
    policy=collapse_policy(W,p,H['coefficients'],I['coefficients'],h,q)
    policy['recovery']=dict(H=H,I=I)
    return policy


def endpoint_policy(h,q):
    """Estimation-optimal, progress-best endpoint with <=d pair atoms.

    Greedy transport realizes E W=1/d and h.W=mean(h). Exact rational versions
    of these formulas are suitable for the independent endpoint certificate.
    """
    h=np.asarray(h,float);d=len(h);mean=float(np.mean(h));delta=h-mean
    low=list(np.flatnonzero(delta<0));high=list(np.flatnonzero(delta>0));equal=list(np.flatnonzero(delta==0))
    W=[];p=[]
    for i in equal:
        w=np.zeros(d);w[i]=1.;W.append(w);p.append(1/d)
    lowcap={i:-delta[i]/d for i in low};highcap={i:delta[i]/d for i in high}
    il=ih=0
    while il<len(low) and ih<len(high):
        i,j=low[il],high[ih];ai,bj=-delta[i],delta[j]
        flow=min(lowcap[i],highcap[j])
        if flow>0:
            w=np.zeros(d);w[i]=bj/(ai+bj);w[j]=ai/(ai+bj)
            W.append(w);p.append(flow*(1/ai+1/bj))
        lowcap[i]-=flow;highcap[j]-=flow
        if lowcap[i]<=0:il+=1
        if highcap[j]<=0:ih+=1
    if not W:W=np.eye(d);p=np.ones(d)/d
    W=np.asarray(W);p=np.asarray(p);p/=p.sum()
    cI=np.full_like(W,1/(1+d*q));cH=np.full_like(W,d/(h.sum()*(1+d*q)))
    policy=collapse_policy(W,p,cH,cI,h,q)
    policy['endpoint_formula']=dict(Istar=1/(d*(1+d*q)),JH=1/(h.sum()*(1+d*q)),
                                    covariance_residual=float(np.max(np.abs(policy['p']@policy['W']-1/d))),
                                    rayleigh_residual=float(np.max(np.abs(policy['W']@h-mean))))
    return policy


def mix_policies(low,high,beta,h,q,refit=True):
    W=np.vstack([low['W'],high['W']]);p=np.r_[(1-beta)*low['p'],beta*high['p']]
    merged=collapse_policy(W,p,np.vstack([low['c_H'],high['c_H']]),
                           np.vstack([low['c_I'],high['c_I']]),h,q)
    guaranteed_H=(1-beta)*low['metrics']['H']['gain']+beta*high['metrics']['H']['gain']
    guaranteed_I=(1-beta)*low['metrics']['I']['gain']+beta*high['metrics']['I']['gain']
    if refit:
        fit=fit_policy(merged['W'],merged['p'],h,q)
        for task in ['H','I']:
            if fit['metrics'][task]['gain']>merged['metrics'][task]['gain']:
                merged['c_'+task]=fit['c_'+task]
        merged['metrics']=policy_metrics(merged,h,q)
    merged['mixing']=dict(beta=float(beta),latent_policy_lower_H=float(guaranteed_H),
                          latent_policy_lower_I=float(guaranteed_I),
                          collapsed_H_improvement=merged['metrics']['H']['gain']-guaranteed_H,
                          collapsed_I_improvement=merged['metrics']['I']['gain']-guaranteed_I,
                          decoders_refitted=bool(refit))
    return merged


class WeightedOracle:
    """Practical finite-cut weighted solver, with actual response recovery.

    Returns U for J_H+multiplier*J_I, never a normalized support value.
    The desired oracle error is in the same absolute J_H units.
    """
    def __init__(self,h,q,max_rounds=100):
        self.h=np.asarray(h,float);self.q=float(q);self.d=len(h);self.max_rounds=max_rounds
        self.optimum=spectral_optimum(self.h,q);self.Istar=1/(self.d*(1+self.d*q))
        base=list(np.eye(self.d))
        base += [(np.eye(self.d)[i]+np.eye(self.d)[j])/2 for i,j in itertools.combinations(range(self.d),2)]
        base += list(endpoint_policy(self.h,q)['W'])
        self.initial_W=np.unique(np.asarray(base),axis=0)

    def _finite_dual(self,W,weights,tol):
        try:import cvxpy as cp
        except ImportError as error:
            raise ImportError('Weighted exchange requires cvxpy and clarabel; install both dependencies.') from error
        z=cp.Variable(self.d,nonneg=True);x=cp.Variable(self.d,nonneg=True);rho=cp.Variable()
        constraints=[cp.sum(z)==1,cp.sum(x)==1];cuts=[]
        ds=max(1.,self.q);co,ce=weights
        for w in W:
            expr=co*cp.quad_over_lin(cp.multiply(np.sqrt(w/self.h/ds),z),(w@z+self.q)/ds)
            if ce>0:expr+=ce*cp.quad_over_lin(cp.multiply(np.sqrt(w/ds),x),(w@x+self.q)/ds)
            cut=expr<=rho;cuts.append(cut);constraints.append(cut)
        problem=cp.Problem(cp.Minimize(rho),constraints)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            problem.solve(solver='CLARABEL',tol_gap_abs=tol,tol_gap_rel=tol,tol_feas=tol,max_iter=500)
        if problem.status not in ('optimal','optimal_inaccurate'):
            raise RuntimeError('Finite weighted dual status: '+str(problem.status))
        p=np.maximum(np.array([c.dual_value for c in cuts]).reshape(-1),0.)
        if p.sum()<=0:raise RuntimeError('No positive recovered design masses')
        p/=p.sum();zz=project_simplex(z.value);xx=project_simplex(x.value)
        return float(problem.value),zz,xx,p,str(problem.status),[str(w.message) for w in caught]

    def solve(self,multiplier,accuracy):
        mu=float(multiplier);eta=float(accuracy);start=time.monotonic()
        if not np.isfinite(mu) or mu<0 or not np.isfinite(eta) or eta<=0:
            raise ValueError('multiplier must be finite nonnegative and accuracy positive')
        if mu==0:
            W=np.eye(self.d);p=self.optimum['coordinate_probabilities'];z=self.optimum['prior']
            cH=z[None,:]/self.h[None,:]/(self.q+W@z)[:,None]
            I=recover_task(W,p,np.ones(self.d),self.q)
            policy=collapse_policy(W,p,cH,I['coefficients'],self.h,self.q)
            x=I['prior'];upper,_,_=pair_oracle(z,x,self.h,self.q,(1.,0.))
            lower=policy['metrics']['H']['gain']
            return dict(multiplier=mu,U_weighted=upper,weighted_decoder_lower=lower,
                        oracle_gap=upper-lower,requested_accuracy=eta,accuracy_met=upper-lower<=eta,
                        dual_prior_H=z,dual_prior_I=x,policy=policy,exchange=[],
                        status='analytic_optimization_endpoint',seconds=time.monotonic()-start)
        scale=self.optimum['value']+mu*self.Istar
        weights=(1/scale,mu/scale);normalized_eta=eta/scale
        tol=max(2e-12,min(2e-10,normalized_eta/100))
        W=self.initial_W.copy();logs=[];best=None;best_upper=np.inf;best_z=best_x=None
        for iteration in range(self.max_rounds):
            restricted,z,x,p,status,notices=self._finite_dual(W,weights,tol)
            upper,_,candidates=pair_oracle(z,x,self.h,self.q,weights)
            if upper<best_upper:best_upper=upper;best_z=z.copy();best_x=x.copy()
            separation=upper-restricted
            logs.append(dict(round=iteration,atoms=len(W),restricted_objective=restricted*scale,
                             separated_upper=upper*scale,separation_gap=separation*scale,
                             solver_status=status,solver_warnings=notices))
            if separation<=max(normalized_eta/3,10*tol) or iteration==self.max_rounds-1:
                keep=p>min(1e-9,normalized_eta*1e-3)
                policy=fit_policy(W[keep],p[keep]/p[keep].sum(),self.h,self.q)
                lower=policy['metrics']['H']['gain']+mu*policy['metrics']['I']['gain']
                if best is None or lower>best[0]:best=(lower,policy)
                if best_upper*scale-best[0]<=eta:break
            new=[]
            for val,w in candidates:
                if val-restricted<=normalized_eta/10:break
                if np.min(np.linalg.norm(W-w,axis=1))>2e-10 and all(np.linalg.norm(v-w)>2e-10 for v in new):new.append(w)
                if len(new)>=self.d:break
            if not new:
                if best is None:
                    policy=fit_policy(W,p,self.h,self.q)
                    best=(policy['metrics']['H']['gain']+mu*policy['metrics']['I']['gain'],policy)
                if tol>2e-12:tol=max(2e-12,tol/10);continue
                break
            W=np.vstack([W,*new])
        if best is None:
            policy=fit_policy(W,p,self.h,self.q)
            best=(policy['metrics']['H']['gain']+mu*policy['metrics']['I']['gain'],policy)
        lower,policy=best;upper=best_upper*scale;gap=upper-lower
        return dict(multiplier=mu,U_weighted=upper,weighted_decoder_lower=lower,oracle_gap=gap,
                    requested_accuracy=eta,accuracy_met=bool(gap<=eta),dual_prior_H=best_z,
                    dual_prior_I=best_x,policy=policy,exchange=logs,
                    status='accuracy_met' if gap<=eta else 'accuracy_not_met',seconds=time.monotonic()-start,
                    normalized_support_scale=scale,normalized_requested_accuracy=normalized_eta)


def _witness(record,target):
    return dict(multiplier=record['multiplier'],dual_prior_H=record['dual_prior_H'],
                dual_prior_I=record['dual_prior_I'],U_weighted=record['U_weighted'],
                V_upper=record['U_weighted']-record['multiplier']*target,
                weighted_decoder_lower=record['weighted_decoder_lower'],oracle_gap=record['oracle_gap'],
                requested_accuracy=record['requested_accuracy'],accuracy_met=record['accuracy_met'],
                solver_status=record['status'],seconds=record['seconds'])


def solve_retention_candidate(h,q,alpha,epsilon,*,max_oracle_calls=64,max_exchange_rounds=100,
                    refit_mixed_decoders=True,numerical_tolerance=1e-11):
    """Return a finite candidate, label-free decoders, and diagnostic brackets.

    Optimization stops at epsilon/4 computed absolute-J_H gap, leaving room
    for independent rationalization/feasibility repair. Every weighted oracle
    is requested at epsilon/8 absolute accuracy. The returned status never
    asserts an exact or outward-rounded mathematical certificate.
    """
    h=np.asarray(h,float)
    if h.ndim!=1 or not len(h) or not np.all(np.isfinite(h)) or np.any(h<=0):raise ValueError('h must be a finite positive spectrum')
    q=float(q);alpha=float(alpha);epsilon=float(epsilon)
    if not np.isfinite(q) or q<=0:raise ValueError('This retention interface requires finite q>0')
    if not np.isfinite(alpha) or not 0<=alpha<=1:raise ValueError('alpha must lie in [0,1]')
    if not np.isfinite(epsilon) or epsilon<=0:raise ValueError('epsilon must be positive and is in absolute J_H units')
    if max_oracle_calls<2 or max_exchange_rounds<1:raise ValueError('Insufficient iteration limits')
    start=time.monotonic();d=len(h);Istar=1/(d*(1+d*q));target=alpha*Istar
    endpoint=endpoint_policy(h,q);eta=epsilon/8;stop_gap=epsilon/4
    oracle=WeightedOracle(h,q,max_exchange_rounds);records=[];history=[];warnings_out=[]
    best=endpoint;special=None
    if alpha==1 or d==1:
        upper=1/(h.sum()*(1+d*q));special='alpha_one_endpoint' if alpha==1 else 'one_dimensional'
        upper_witnesses=[];status='endpoint_formula'
    else:
        zero=oracle.solve(0.,eta);records.append(zero)
        upper=zero['U_weighted'];upper_witnesses=[_witness(zero,target)]
        if zero['policy']['metrics']['I']['gain']>=target:best=zero['policy']
        elif upper-best['metrics']['H']['gain']>stop_gap:
            low=zero;Delta=(1-alpha)*Istar
            hE=1/(h.sum()*(1+d*q));B=(zero['U_weighted']-hE+2*eta)/Delta
            high=None
            for _ in range(8):
                current=oracle.solve(B,eta);records.append(current);upper_witnesses.append(_witness(current,target))
                if not current['accuracy_met']:warnings_out.append('A weighted solve missed its requested epsilon/8 accuracy; only the final computed bracket is used.')
                if current['policy']['metrics']['I']['gain']>=target:high=current;break
                B*=2
                if len(records)>=max_oracle_calls:break
            if high is not None:
                while True:
                    il=low['policy']['metrics']['I']['gain'];ih=high['policy']['metrics']['I']['gain']
                    # A small positive retention margin protects the candidate
                    # from subsequent rounding; exact feasibility is checked elsewhere.
                    buffer=min(Delta/128,epsilon/(128*max(1.,high['multiplier'])),max(0.,ih-target)/4)
                    beta=float(np.clip((target+buffer-il)/(ih-il),0.,1.))
                    mixed=mix_policies(low['policy'],high['policy'],beta,h,q,refit_mixed_decoders)
                    feasible=[p for p in [best,high['policy'],mixed] if p['metrics']['I']['gain']>=target]
                    if feasible:best=max(feasible,key=lambda p:p['metrics']['H']['gain'])
                    upper=min(w['V_upper'] for w in upper_witnesses)
                    history.append(dict(lambda_low=low['multiplier'],lambda_high=high['multiplier'],
                                        I_low=il,I_high=ih,beta=beta,retention_buffer=buffer,
                                        candidate_I=best['metrics']['I']['gain'],candidate_H=best['metrics']['H']['gain'],
                                        V_upper=upper,gap=upper-best['metrics']['H']['gain']))
                    if best['metrics']['I']['gain']>=target and upper-best['metrics']['H']['gain']<=stop_gap:break
                    if len(records)>=max_oracle_calls:break
                    mid=(low['multiplier']+high['multiplier'])/2
                    if mid==low['multiplier'] or mid==high['multiplier']:break
                    current=oracle.solve(mid,eta);records.append(current);upper_witnesses.append(_witness(current,target))
                    if not current['accuracy_met']:warnings_out.append('A weighted solve missed its requested epsilon/8 accuracy; only the final computed bracket is used.')
                    if current['policy']['metrics']['I']['gain']>=target:high=current
                    else:low=current
            else:warnings_out.append('Could not obtain a computed feasible high-multiplier policy within the limits.')
        upper=min(w['V_upper'] for w in upper_witnesses)
        status='candidate_ready'
    lower=best['metrics']['H']['gain'];actual_I=best['metrics']['I']['gain'];gap=upper-lower
    arithmetic_scale=max([1.,abs(upper)]+[abs(r['U_weighted']) for r in records])
    precision=max(float(numerical_tolerance),128*np.finfo(float).eps*arithmetic_scale)
    feas=actual_I>=target-precision;gap_met=gap<=epsilon
    inner_met=actual_I>=target-precision and gap<=stop_gap
    if gap < -precision:status='numerical_bracket_inconsistency'
    elif not feas or not gap_met:status='tolerance_not_met'
    elif precision>epsilon/16:status='numerical_precision_limit'
    elif special is None:status='candidate_ready' if inner_met else 'outer_tolerance_only'
    selected=min(upper_witnesses,key=lambda w:w['V_upper']) if upper_witnesses else dict(kind=special,formula='1/(sum(h)*(1+d*q))')
    result=dict(schema_version='retention_candidate_v1',input=dict(h=h,q=q,alpha=alpha,epsilon_absolute_JH=epsilon),
                normalization=dict(G=1.,Istar=Istar,retention_target=target,
                                   optimization_gain='J_H = 2 expected quadratic decrease / G^2',estimation_gain='J_I = 1 - MSE/G^2'),
                response_scope='all measurable responses under the conditional-moment model' if q>=1/3 else 'linear responses only',
                status=status,candidate=best,upper_witnesses=upper_witnesses,selected_upper_witness=selected,
                numerical_certificate=dict(kind='floating_point_diagnostic_not_interval_proof',rigorous=False,
                    actual_JI=actual_I,actual_JH=lower,V_upper=upper,V_gap=gap,retention_margin=actual_I-target,
                    feasibility_within_tolerance=bool(feas),gap_within_epsilon=bool(gap_met),
                    epsilon_quarter_candidate_goal_met=bool(inner_met),arithmetic_tolerance_absolute=precision,
                    requested_oracle_error_absolute=eta),
                oracle_calls=len(records),multiplier_history=history,warnings=sorted(set(warnings_out)),
                raw_oracle_records=records,seconds=time.monotonic()-start,
                dependencies=['numpy','scipy','cvxpy','clarabel'],
                exact_verification_contract='Rationalize W,p,c_H,c_I and each multiplier/prior; collapse duplicate amplitudes; recompute actual gain matrices; repair retention if needed; certify global weighted pair upper independently.')
    return jsonable(result)


def _exact_module():
    # Resolve the sibling independently of the caller's working directory or
    # whether this module was loaded through importlib rather than sys.path.
    import importlib.util
    path=Path(__file__).resolve().with_name('exact_certificate.py')
    spec=importlib.util.spec_from_file_location('_retention_exact_certificate',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def _policy_atoms(candidate):
    return [dict(p=p,W=w,c_H=ch,c_I=ci) for p,w,ch,ci in
            zip(candidate['p'],candidate['W'],candidate['c_H'],candidate['c_I'])]


def solve_retention(h,q,alpha,epsilon,*,weighted_backend='exchange',max_refinements=3,
                    rational_grid=10**12,**candidate_options):
    """Return an EXACTLY verified finite policy, or raise an honest failure.

    The JSON-compatible return value can be written directly and independently
    checked by exact_certificate.verify_saved(path). Its extra `solver` and
    `numerical_candidate` fields are diagnostics, not part of the proof.

    This practical exchange backend has no universal finite-runtime claim.
    Each returned result has a full exact feasibility/global-gap certificate;
    exhausted numerical iterations or failed exact acceptance raise RuntimeError.
    """
    if weighted_backend!='exchange':raise ValueError('Available practical weighted_backend: exchange')
    if max_refinements<1:raise ValueError('max_refinements must be positive')
    exact=_exact_module();hf=[exact.fraction(x) for x in h]
    qf,af,ef=map(exact.fraction,[q,alpha,epsilon])
    if not hf or min(hf)<=0 or qf<=0 or not 0<=af<=1 or ef<=0:raise ValueError('Require positive h,q, alpha in [0,1], and positive absolute-J_H epsilon')
    start=time.monotonic();attempts=[];all_duals=[];candidate=None
    shortcut=exact.endpoint_modulus_squared(hf,qf)*(1-af)<=ef**2
    if shortcut:
        proof=exact.certify([],hf,qf,af,ef,grid=rational_grid)
    else:
        proof=None
        for refinement in range(max_refinements):
            working_epsilon=float(ef)/(4**refinement)
            attempt=dict(refinement=refinement,working_epsilon_absolute_JH=working_epsilon)
            try:
                candidate=solve_retention_candidate([float(x) for x in hf],float(qf),float(af),
                                                     working_epsilon,**candidate_options)
                attempt.update(candidate_status=candidate['status'],oracle_calls=candidate['oracle_calls'],
                               computed_gap=candidate['numerical_certificate']['V_gap'],
                               computed_retention_margin=candidate['numerical_certificate']['retention_margin'])
                all_duals += [dict(multiplier=w['multiplier'],zH=w['dual_prior_H'],zI=w['dual_prior_I'])
                              for w in candidate['upper_witnesses']]
                proof=exact.certify(_policy_atoms(candidate['candidate']),hf,qf,af,ef,
                                    dual_candidates=all_duals,grid=rational_grid*(10**refinement))
                attempt['exact_acceptance']='passed';attempts.append(attempt);break
            except (ValueError,ArithmeticError,RuntimeError) as error:
                attempt['exact_acceptance']='failed';attempt['error']=str(error);attempts.append(attempt)
        if proof is None:
            raise RuntimeError('Practical exchange did not return an exactly accepted policy: '+json.dumps(attempts))
    result=exact.jsonable(proof)
    result['status']='exact_certified'
    result['solver']=dict(weighted_backend=weighted_backend,endpoint_shortcut=bool(shortcut),
                          attempts=attempts,seconds=time.monotonic()-start,
                          oracle_calls=sum(a.get('oracle_calls',0) for a in attempts),
                          algorithmic_scope='Exact acceptance of the returned policy; exchange does not inherit the theoretical OGD iteration bound.',
                          numerical_dependencies=['numpy','scipy','cvxpy','clarabel'],
                          verifier_dependencies='Python standard library only')
    result['numerical_candidate']=candidate
    return result


def _array_policy(candidate):
    if isinstance(candidate,dict) and 'policy' in candidate:
        candidate=candidate['policy']
    parse=lambda x:float(Fraction(str(x)))
    if isinstance(candidate,list):
        result=dict(W=np.array([[parse(v) for v in a['W']] for a in candidate]),
                    p=np.array([parse(a['p']) for a in candidate]),
                    c_H=np.array([[parse(v) for v in a['c_H']] for a in candidate]),
                    c_I=np.array([[parse(v) for v in a['c_I']] for a in candidate]))
    else:result={k:np.asarray(candidate[k],float) for k in ['W','p','c_H','c_I']}
    # Exact rational atoms can be distinct yet collapse to one float. Never
    # silently turn that into a hidden-label-dependent decoder implementation.
    roots=np.sqrt(result['W']);seen={}
    for j,root in enumerate(roots):
        key=tuple(root)
        if key in seen:
            i=seen[key]
            active=np.maximum(result['W'][i],result['W'][j])>0
            if any(not np.array_equal(result[key][i,active],result[key][j,active]) for key in ['c_H','c_I']):
                raise ValueError('Distinct atoms with different decoders are indistinguishable at floating precision; use higher-precision execution.')
        else:seen[key]=j
    return result


class CompiledRetentionPolicy:
    """Observation-only execution demonstrator for a certified rational law.

    The certificate defines the mathematical policy exactly. This helper uses
    floating square roots/measurements and does not certify hardware rounding
    or a physical noise source; unresolved floating atom collisions raise.
    """
    def __init__(self,certificate):
        self._policy=_array_policy(certificate)
        self._roots=np.sqrt(self._policy['W'])
        self._probabilities=self._policy['p']/self._policy['p'].sum()
        self._lookup={tuple(row):i for i,row in enumerate(self._roots)}

    def sample_direction(self,rng=None):
        rng=np.random.default_rng() if rng is None else rng
        row=int(rng.choice(len(self._probabilities),p=self._probabilities))
        return self._roots[row]*rng.choice([-1.,1.],size=self._roots.shape[1])

    def _decode(self,u,Y,task):
        u=np.asarray(u,float)
        key=tuple(abs(u))
        if key not in self._lookup:raise ValueError('Observed direction is outside the stored floating probe law; pass the sampled u without modification')
        row=self._lookup[key]
        return self._policy['c_'+task][row]*u*Y

    def decode_H(self,u,Y):return self._decode(u,Y,'H')

    def decode_I(self,u,Y):return self._decode(u,Y,'I')


def compile_policy(certificate):
    """Compile once, then use sample_direction(rng), decode_H(u,Y), decode_I(u,Y)."""
    return CompiledRetentionPolicy(certificate)


def sample_probe(candidate,rng=None):
    """Return only u, with no latent-component label."""
    return compile_policy(candidate).sample_direction(rng)


def decode_response(candidate,u,Y,task):
    """Finite-support coefficient lookup depending only on the observed u,Y.

    The mathematical lookup is exact at W=u^2. The execution lookup uses the
    stored floating absolute direction exactly; no hidden label is accepted.
    """
    if task not in ('H','I'):raise ValueError('task must be H or I')
    return compile_policy(candidate)._decode(u,Y,task)


def run_validation_suite(output_directory):
    """Small deterministic integration suite; save and re-read every proof.

    This checks returned certificates, not a finite-runtime theorem for the
    exchange backend. Decimal strings deliberately survive to exact parsing.
    The figure uses numerical renderings of exact rational bounds.
    """
    output=Path(output_directory);output.mkdir(parents=True,exist_ok=True)
    certificate_directory=output/'certificates';certificate_directory.mkdir(exist_ok=True)
    exact=_exact_module();cases=[];rows=[]
    spectra=[('two_scale',[1,4]),('four_scale',[1,4,25,100]),('spiked_six',[1,1,1,1,1,100])]
    alphas=['0','0.5','0.9','0.99','0.9999','0.99999999','1']
    for name,h in spectra:
        for a in alphas:cases.append((name,h,'0.5',a,'0.0001','main'))
    for name,h,a in [('two_scale',[1,4],'0.99'),('four_scale',[1,4,25,100],'0.99'),
                     ('spiked_six',[1,1,1,1,1,100],'0.9999')]:
        cases.append((name,h,'0.5',a,'0.00001','tight'))
    cases += [('four_scale',[1,4,25,100],'0.1','0.9','0.0001','linear_scope'),
              ('two_scale',[1,4],'1/3','0.99','0.00001','scope_boundary')]
    baseline_for_repair=None
    for index,(name,h,q,a,e,group) in enumerate(cases):
        result=solve_retention(h,q,a,e)
        filename=f'{index:02d}_{name}_{group}.json';path=certificate_directory/filename
        path.write_text(json.dumps(result,indent=2)+'\n')
        verified=exact.verify_saved(path)
        if not verified['passed']:raise AssertionError('Independent re-read verification failed')
        rng=np.random.default_rng(771+index);execution=compile_policy(result)
        for _ in range(3):
            u=execution.sample_direction(rng)
            for decoder in [execution.decode_H,execution.decode_I]:
                response=decoder(u,.7)
                if not np.all(np.isfinite(response)):raise AssertionError('Nonfinite decoded response')
        Jstar=spectral_optimum(h,float(Fraction(q)))['value']
        row=dict(name=name,h=h,q=q,alpha=a,epsilon=e,group=group,
                 certificate='certificates/'+filename,verified=verified,
                 JH=result['actual_gain_H'],JI=result['actual_gain_I'],
                 V_upper=result['optimality_upper'],gap=result['optimality_gap'],
                 slack=result['feasibility_slack'],repair_weight=result['repair_weight'],
                 gap_over_epsilon=float(Fraction(result['optimality_gap'])/Fraction(e)),
                 epsilon_over_unconstrained_JH=float(Fraction(e))/Jstar,
                 unconstrained_JH_numerical=Jstar,amplitude_atoms=result['amplitude_atoms'],
                 weighted_calls=result['solver']['oracle_calls'],
                 endpoint_shortcut=result['solver']['endpoint_shortcut'],
                 response_scope=result['response_scope'],seconds=result['solver']['seconds'])
        rows.append(row)
        if name=='two_scale' and group=='main' and a=='0.99':baseline_for_repair=result
        print(json.dumps({k:row[k] for k in ['name','q','alpha','epsilon','group','gap_over_epsilon',
                                           'amplitude_atoms','weighted_calls','endpoint_shortcut']}),flush=True)
    # Deliberately attenuate the estimation decoder. This is an integration
    # test of nonzero repair, not a claim that ordinary rounding is this large.
    source=baseline_for_repair
    perturbed=[dict(p=Fraction(atom['p']),W=list(map(Fraction,atom['W'])),
                    c_H=list(map(Fraction,atom['c_H'])),
                    c_I=[Fraction(199,200)*Fraction(c) for c in atom['c_I']]) for atom in source['policy']]
    before=exact.gains(perturbed,[1,4],Fraction(1,2))['I']['value']
    repaired=exact.certify(perturbed,[1,4],Fraction(1,2),Fraction(99,100),Fraction(1,10000),
                           dual_candidates=source['dual_candidates'],already_rational=True)
    if repaired['repair_weight']<=0:raise AssertionError('Forced repair did not exercise a positive weight')
    path=certificate_directory/'forced_positive_repair.json'
    path.write_text(json.dumps(exact.jsonable(repaired),indent=2)+'\n')
    repair_check=exact.verify_saved(path)
    repair=dict(coefficient_multiplier='199/200',pre_repair_JI=str(before),target_I=str(repaired['target_I']),
                repair_weight=str(repaired['repair_weight']),post_repair_JI=str(repaired['actual_gain_I']),
                post_repair_JH=str(repaired['actual_gain_H']),gap=str(repaired['optimality_gap']),
                feasibility_slack=str(repaired['feasibility_slack']),verified=repair_check,
                certificate='certificates/forced_positive_repair.json',
                interpretation='Synthetic decoder attenuation exercises endpoint repair; it does not measure ordinary rounding error.')
    overlap=[dict(p=Fraction(1,3),W=[Fraction(1,2)]*2,c_H=[Fraction(1,10),Fraction(1,20)],c_I=[Fraction(1,4),Fraction(1,2)]),
             dict(p=Fraction(2,3),W=[Fraction(1,2)]*2,c_H=[Fraction(1,5),Fraction(1,10)],c_I=[Fraction(1,2),Fraction(1,4)])]
    collapsed=exact.merge_policy(overlap)
    if len(collapsed)!=1 or collapsed[0]['c_H']!=[Fraction(1,6),Fraction(1,12)] or collapsed[0]['c_I']!=[Fraction(5,12),Fraction(1,3)]:
        raise AssertionError('Overlapping amplitude label collapse failed')
    execution=compile_policy(collapsed);u=execution.sample_direction(np.random.default_rng(51))
    if not np.allclose(execution.decode_I(u,.7),np.array([5/12,1/3])*u*.7,rtol=0,atol=1e-16):
        raise AssertionError('Observation-only decoder failed after label collapse')
    tiny=Fraction(1,10**40)
    collision=[dict(p=Fraction(1,2),W=[Fraction(1,2)-tiny,Fraction(1,2)+tiny],c_H=[Fraction(1,2)]*2,c_I=[Fraction(1,2)]*2),
               dict(p=Fraction(1,2),W=[Fraction(1,2)+tiny,Fraction(1,2)-tiny],c_H=[Fraction(1,4)]*2,c_I=[Fraction(1,4)]*2)]
    try:compile_policy(collision)
    except ValueError:pass
    else:raise AssertionError('Ambiguous floating execution was not rejected')
    summary=dict(schema='retention_validation_v1',cases=rows,forced_positive_repair=repair,
                 overlapping_atom_check=dict(passed=True,collapsed_policy=exact.jsonable(collapsed)),
                 runtime_checks=dict(all_ordinary_policies_compile=True,collision_rejection_passed=True,
                                     lookup='Exact floating keys of abs(u); no latent labels or nearest-label matching.'),
                 arithmetic='All saved certificates reverified by standard-library Fraction arithmetic.',
                 runtime_scope='Observed wall times only; exchange has no asserted worst-case termination bound.',
                 units='epsilon is absolute J_H; all relative errors divide recoverable J_H, not total MSE.')
    (output/'retention_validation.json').write_text(json.dumps(summary,indent=2)+'\n')
    return summary


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    # Preserve the decimal/rational input text for exact near-endpoint checks.
    parser.add_argument('--h',nargs='+');parser.add_argument('--q')
    parser.add_argument('--alpha');parser.add_argument('--epsilon')
    parser.add_argument('--output',type=Path);parser.add_argument('--max-oracle-calls',type=int,default=64)
    parser.add_argument('--candidate-only',action='store_true',help='Return only floating diagnostics; no exact acceptance')
    parser.add_argument('--validation-suite',type=Path,help='Run the compact integration suite and save proofs in this directory')
    args=parser.parse_args()
    if args.validation_suite:
        run_validation_suite(args.validation_suite);return
    if any(getattr(args,k) is None for k in ['h','q','alpha','epsilon']):
        parser.error('--h, --q, --alpha, and --epsilon are required unless --validation-suite is used')
    solver=solve_retention_candidate if args.candidate_only else solve_retention
    result=solver(args.h,args.q,args.alpha,args.epsilon,max_oracle_calls=args.max_oracle_calls)
    if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2)+'\n')
    if args.candidate_only:
        summary={k:result[k] for k in ['input','status','numerical_certificate','oracle_calls','seconds']}
    else:
        summary={k:result[k] for k in ['h','q','alpha','epsilon','status','amplitude_atoms','response_scope','solver']}
        summary.update(actual_JH=float(Fraction(result['actual_gain_H'])),
                       actual_JI=float(Fraction(result['actual_gain_I'])),
                       exact_gap=float(Fraction(result['optimality_gap'])),
                       exact_feasibility_slack=float(Fraction(result['feasibility_slack'])))
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
