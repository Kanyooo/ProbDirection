"""Independently recheck saved retention policies; no optimizer dependencies."""
import json
from pathlib import Path

from exact_certificate import verify_saved


def main():
    code = Path(__file__).resolve().parent
    experiments = sorted((code.parent / 'results' / 'certificates').glob('*.json'))
    if len(experiments) != 27:
        raise ValueError(f'Expected 27 experiment certificates, found {len(experiments)}')
    records = []
    for path in experiments:
        result = verify_saved(path)
        records.append({'file': path.name, **result})
    print(json.dumps({'passed': True, 'experiment_certificates': len(experiments),
                      'records': records}, indent=2))


if __name__ == '__main__':
    main()
