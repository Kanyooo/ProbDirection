"""Reproducible exact checks of the certificate interface and its edge cases."""
from fractions import Fraction as F
import json
from pathlib import Path
import random
import tempfile

from exact_certificate import (certify, endpoint_policy, gains, jsonable,
                               mix, pair_upper, simplex, verify_saved)


def exact_example():
    h=[F(935,207),F(1)];q=F(7,10);r=F(5,8)
    z=[F(3,4),F(1,4)];x=[F(2,5),F(3,5)]
    dh=q+r*z[0]+(1-r)*z[1];di=q+r*x[0]+(1-r)*x[1]
    kh=z[0]**2/h[0]*(z[1]+q)-z[1]**2/h[1]*(z[0]+q)
    ki=x[0]**2*(x[1]+q)-x[1]**2*(x[0]+q)
    mu=-(kh/dh**2)/(ki/di**2)
    policy=[{'p':F(1),'W':[r,1-r],
             'c_H':[z[i]/(h[i]*dh) for i in range(2)],
             'c_I':[x[i]/di for i in range(2)]}]
    return certify(policy,h,q,F(24,25),F(1,10**8),
                   [{'multiplier':mu,'zH':z,'zI':x}],already_rational=True)


def main():
    for n in range(1,9):
        for grid in range(1,12):
            rounded=simplex([F(1,n)]*n,grid)
            assert min(rounded)>=0 and sum(rounded)==1
            assert sum(abs(x-F(1,n)) for x in rounded)<=F(n,grid)
    for h,q in [([1],1),([2,2,2],F(1,2)),([1,4],1),
                ([1,4,25,100],1),([1,1,1,1,1,100],F(1,2))]:
        ep=endpoint_policy(h,q)
        assert len(ep)<=len(h)
        c=certify([],h,q,1,F(1,10**6))
        assert c['optimality_gap']==0

    # Same physical directions arise under both policies, with different
    # conditional component probabilities. Unconditional averaging is wrong.
    w1=[F(1,3),F(2,3)];w2=[F(2,3),F(1,3)]
    p1=[{'p':p,'W':w,'c_H':[F(1,10),F(1,5)],'c_I':[F(1,4),F(1,3)]}
        for p,w in [(F(3,4),w1),(F(1,4),w2)]]
    p2=[{'p':p,'W':w,'c_H':[F(1,5),F(1,10)],'c_I':[F(1,3),F(1,4)]}
        for p,w in [(F(1,4),w1),(F(3,4),w2)]]
    merged=mix([p1,p2],[F(1,2),F(1,2)])
    assert merged[0]['c_H'][0]==F(1,8)
    stats=[gains(p,[1,4],1) for p in [p1,p2,merged]]
    for task in ('H','I'):
        assert stats[2][task]['value']>=(stats[0][task]['value']+stats[1][task]['value'])/2

    rng=random.Random(20260929); stationary=0
    for case in range(24):
        d=rng.choice([2,3,4,6]);h=[F(rng.randint(1,20)) for _ in range(d)]
        q=F(rng.randint(1,8),4);mu=F(rng.randint(0,30),7)
        zh=[rng.randint(1,20) for _ in range(d)];zi=[rng.randint(1,20) for _ in range(d)]
        zh=[F(x,sum(zh)) for x in zh];zi=[F(x,sum(zi)) for x in zi]
        b=pair_upper(h,q,zh,zi,mu,F(1,10**7));w=b['W']
        stationary+=b['stationary_edges']
        value=sum(w[i]*zh[i]**2/h[i] for i in range(d))/(q+sum(w[i]*zh[i] for i in range(d)))
        value+=mu*sum(w[i]*zi[i]**2 for i in range(d))/(q+sum(w[i]*zi[i] for i in range(d)))
        assert value==b['lower'] and b['upper']-b['lower']<=F(1,10**7)
        # A finite diagnostic grid supplements, rather than replaces, the proof.
        for i in range(d):
            for j in range(i+1,d):
                for k in range(21):
                    t=F(k,20)
                    v=(t*zh[i]**2/h[i]+(1-t)*zh[j]**2/h[j])/(q+t*zh[i]+(1-t)*zh[j])
                    v+=mu*(t*zi[i]**2+(1-t)*zi[j]**2)/(q+t*zi[i]+(1-t)*zi[j])
                    assert v<=b['upper']

    certificate=exact_example()
    path=Path(__file__).with_name('exact_rational_example.json')
    path.write_text(json.dumps(jsonable(certificate),indent=2)+'\n')
    checked=verify_saved(path)
    assert certificate['optimality_gap']==0
    assert certificate['feasibility_slack']==0
    # A certificate checker must reject incorrect reported fields/dimensions.
    with tempfile.TemporaryDirectory() as folder:
        for mutation in ('gap','dimension'):
            wrong=json.loads(path.read_text())
            if mutation=='gap':wrong['optimality_gap']='1/2'
            else:
                wrong['policy'][0]['W'].append('0')
                wrong['policy'][0]['c_H'].append('0')
                wrong['policy'][0]['c_I'].append('0')
            target=Path(folder)/'wrong.json';target.write_text(json.dumps(wrong))
            try: verify_saved(target)
            except (AssertionError,ValueError): pass
            else: raise AssertionError('Tampered certificate was accepted')
    result={'status':'PASS','endpoint_cases':5,'simplex_rounding_cases':88,
            'rational_oracle_cases':24,'interior_stationary_edges':stationary,
            'overlapping_label_case':True,'rejected_tampered_certificates':2,
            'exact_constrained_example':checked}
    Path(__file__).with_name('exact_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
