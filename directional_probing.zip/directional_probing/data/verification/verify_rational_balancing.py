"""Exact rational example of same-covariance, simultaneous gain improvement.

This checks the finite algebra in the analytic high-noise minimax theorem.
The upper bounds apply to every decoder in the conditional-moment model.
No numerical optimizer or third-party package is needed.
"""
from fractions import Fraction as F
from pathlib import Path
import json

def main():
    h=(F(935,207),F(1))
    q=F(7,10)
    p=(F(5,8),F(3,8))
    assert sum(p)==1 and q>=F(1,3)
    rows=[]
    for name,H,z,target,axis_target in [
        ("optimization",h,(F(3,4),F(1,4)),F(15,187),F(129165,1648592)),
        ("estimation",(F(1),F(1)),(F(2,5),F(3,5)),F(1,5),F(557,2860)),
    ]:
        assert sum(z)==1 and all(t>0 for t in z)
        D=q+sum(pi*zi for pi,zi in zip(p,z))
        numerator=sum(pi*zi*zi/hi for pi,zi,hi in zip(p,z,H))
        bayes=numerator/D
        N=numerator/D**2
        B=[2*pi*zi/(hi*D)-pi*N for pi,zi,hi in zip(p,z,H)]
        attained=min(B)-q*N
        assert B[0]==B[1]
        assert attained==bayes==target
        axis_upper=sum(pi*zi*zi/(hi*(zi+q)) for pi,zi,hi in zip(p,z,H))
        assert axis_upper==axis_target<attained
        rows.append(dict(task=name,balanced_exact=str(attained),
                         axis_all_decoder_upper=str(axis_upper),
                         absolute_improvement_at_least=str(attained-axis_upper),
                         relative_improvement_at_least=str(attained/axis_upper-1),
                         relative_improvement_percent=100*float(attained/axis_upper-1),
                         prior=[str(t) for t in z],
                         denominator=str(D),signal_diagonal=[str(t) for t in B]))
    result=dict(passed=True,arithmetic="fractions.Fraction",q=str(q),
                H=[str(t) for t in h],
                common_second_moment_diagonal=[str(t) for t in p],
                randomized_axis_energy_variance=str(p[0]*p[1]),
                balanced_energy_variance="0",tasks=rows,
                scope="Exact algebraic instance of the proved high-noise covariance reduction; not a numerical search.")
    out=Path(__file__).with_suffix(".json")
    out.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    main()

