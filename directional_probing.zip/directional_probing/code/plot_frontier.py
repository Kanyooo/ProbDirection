#!/usr/bin/env python3
"""Redraw the exact frontier from generated results; no optimization is run.

Run from any directory: python plot_frontier.py
By default, reads ../data/numerics/frontier_plot.json relative to this script.
Use --data-root DATA_DIRECTORY or --data PATH_TO_JSON to override the input.
The caption below specifies the two different horizontal-axis conventions.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np


DEFAULT_DATA_ROOT = Path(__file__).resolve().parents[1] / "data"
OUT = Path(__file__).resolve().parents[1] / "figures"

CAPTION = (
    "Exact two-task frontier for H = diag(100,1,1,1,1,1) and q = 0.5. "
    "(a) The blue curve is the optimal normalized descent gain subject to "
    "required estimation retention alpha; its dotted plateau is inactive for "
    "alpha <= alpha_star = 0.5701. The plateau is attained by Q_{r_star}, "
    "whose achieved retention is alpha_star. The orange dashed curve plots "
    "achieved estimation retention against achieved descent gain for the "
    "selected endpoint mixture (1-t)Q_{r_iso} + t Q_{r_star}, with both "
    "decoders reoptimized for every t. It is not an optimum or bound over "
    "all mixtures of endpoint-optimal laws. (b) At r_bar = (r_iso+r_star)/2, "
    "the balanced probe Q_{r_bar} and the selected 50:50 endpoint mixture "
    "have exactly the same full covariance. Balancing increases estimation "
    "gain by 1.31% and descent gain by 7.20%, relative to that mixture. "
    "The plot uses numerical evaluations of the analytic results."
)

BLUE = "#2463A6"
ORANGE = "#D07A27"
INK = "#243042"
GRID = "#DCE2E8"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT,
                        help="Data directory containing numerics/frontier_plot.json.")
    parser.add_argument("--data", type=Path,
                        help="Exact JSON input path; overrides --data-root.")
    args = parser.parse_args()
    data_path = args.data if args.data is not None else args.data_root / "numerics" / "frontier_plot.json"
    data = json.loads(data_path.read_text())
    par = data["parameters"]
    frontier = data["frontier"]
    mixture = data["selected_endpoint_mixture"]
    midpoint = data["midpoint"]

    active = [p for p in frontier if p["required_retention"] >= par["alpha_star"] - 1e-13]
    fx = np.array([p["required_retention"] for p in active])
    fy = np.array([p["normalized_progress"] for p in active])
    mx = np.array([p["achieved_retention"] for p in mixture])
    my = np.array([p["normalized_progress"] for p in mixture])
    bp = midpoint["balanced"]
    mp = midpoint["selected_mixture"]
    bx, by = bp["retention"], bp["normalized_progress"]
    sx, sy = mp["retention"], mp["normalized_progress"]
    inc_i = 100 * midpoint["relative_improvement_over_mixture"]["I"]
    inc_h = 100 * midpoint["relative_improvement_over_mixture"]["H"]

    # Validate only the stored quantities used in the drawing.
    assert abs(inc_i - 1.3140503988301688) < 1e-10
    assert abs(inc_h - 7.196807046958043) < 1e-10
    assert abs(bx / sx - 1 - inc_i / 100) < 1e-12
    assert abs(by / sy - 1 - inc_h / 100) < 1e-12
    assert np.all(np.diff(fx) >= 0)

    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 8.2,
        "axes.titlesize": 9.0,
        "axes.labelsize": 8.5,
        "xtick.labelsize": 8.0,
        "ytick.labelsize": 8.0,
        "mathtext.fontset": "stix",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "text.color": INK,
        "axes.labelcolor": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.edgecolor": "#A5AFBB",
        "axes.linewidth": 0.65,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
    })

    fig, (ax, zoom) = plt.subplots(
        1, 2, figsize=(6.8, 2.65),
        gridspec_kw={"width_ratios": [1.50, 1.0]},
    )
    fig.subplots_adjust(left=0.081, right=0.985, bottom=0.215, top=0.868, wspace=0.31)

    for axis in (ax, zoom):
        axis.set_axisbelow(True)
        axis.grid(color=GRID, linewidth=0.6, alpha=0.82)
        axis.spines[["top", "right"]].set_visible(False)
        axis.tick_params(length=3.0, width=0.65, pad=3)
        axis.plot(fx, fy, color=BLUE, linewidth=2.0, zorder=3,
                  solid_capstyle="round")
        axis.plot(mx, my, color=ORANGE, linewidth=1.7,
                  linestyle=(0, (4.1, 2.2)), zorder=3,
                  dash_capstyle="round")
        axis.scatter([bx], [by], s=28, color=BLUE, edgecolor="white",
                     linewidth=0.75, zorder=6)
        axis.scatter([sx], [sy], s=28, color=ORANGE, marker="D",
                     edgecolor="white", linewidth=0.75, zorder=6)

    # The plateau encodes required retention, not achieved retention.
    ax.plot([0, par["alpha_star"]], [1, 1], color=BLUE,
            linewidth=1.7, linestyle=(0, (1.0, 2.0)), zorder=3,
            dash_capstyle="round")
    ax.scatter([par["alpha_star"], 1], [1, fy[-1]], s=21,
               color="white", edgecolor=BLUE, linewidth=1.0, zorder=5)
    ax.set(xlim=(0, 1.025), ylim=(0.48, 1.065),
           xticks=[0, .2, .4, .6, .8, 1.0], yticks=[.5, .6, .7, .8, .9, 1.0])
    ax.set_title("(a) Complete constrained frontier", loc="left", pad=9, fontweight="bold")
    ax.set_xlabel(r"Required estimation retention $\alpha$", labelpad=5)
    ax.set_ylabel(r"Normalized descent gain $J_H/J_H^\star$", labelpad=7)
    ax.text(.035, .966, "Inactive constraint", color=BLUE, fontsize=8.0)
    ax.annotate(r"$Q_{r_\star}$", xy=(par["alpha_star"], 1),
                xytext=(5, 7), textcoords="offset points", color=BLUE,
                fontsize=9.0, ha="left", va="bottom")
    ax.annotate(r"$Q_{r_{\rm iso}}$", xy=(1, fy[-1]),
                xytext=(-8, 3), textcoords="offset points", color=BLUE,
                fontsize=9.0, ha="right", va="bottom")

    ax.annotate("Balanced probes\n(exact frontier)", xy=(.75, np.interp(.75, fx, fy)),
                xytext=(.075, .817), color=BLUE, fontsize=8.3,
                ha="left", va="center", linespacing=1.25,
                arrowprops={"arrowstyle": "-", "color": BLUE, "lw": .8,
                            "shrinkA": 5, "shrinkB": 4})
    order = np.argsort(mx)
    ax.annotate("Selected endpoint\nmixture", xy=(.90, np.interp(.90, mx[order], my[order])),
                xytext=(.075, .665), color=ORANGE, fontsize=8.3,
                ha="left", va="center", linespacing=1.25,
                arrowprops={"arrowstyle": "-", "color": ORANGE, "lw": .8,
                            "shrinkA": 5, "shrinkB": 4})
    ax.add_patch(Rectangle((.812, .785), .072, .14, fill=False,
                           edgecolor="#8997A8", linewidth=.7,
                           linestyle=(0, (2.5, 2.5)), zorder=2))

    zoom.set(xlim=(.812, .884), ylim=(.785, .925),
             xticks=[.82, .84, .86, .88], yticks=[.80, .84, .88, .92])
    zoom.set_title("(b) Same covariance", loc="left", pad=9, fontweight="bold")
    zoom.set_xlabel(r"Achieved estimation gain $J_I/J_I^\star$", labelpad=5)
    zoom.text(bx + .0022, by + .010, "Balanced", color=BLUE,
              fontsize=8.2, ha="left", va="center")
    zoom.annotate("50:50 mixture", xy=(sx, sy), xytext=(.815, .861),
                  color=ORANGE, fontsize=8.0, ha="left", va="center",
                  arrowprops={"arrowstyle": "-", "color": ORANGE,
                              "lw": .75, "shrinkA": 4, "shrinkB": 5})

    # An L-shaped decomposition keeps both percentage labels off the curves.
    arrow_kw = {"arrowstyle": "-|>", "mutation_scale": 7.0,
                "color": INK, "lw": .85, "shrinkA": 2.0, "shrinkB": 2.5}
    zoom.annotate("", xy=(bx, sy), xytext=(sx, sy), arrowprops=arrow_kw, zorder=5)
    zoom.annotate("", xy=(bx, by), xytext=(bx, sy), arrowprops=arrow_kw, zorder=5)
    zoom.text(.816, .804, f"+{inc_i:.2f}%\nestimation", fontsize=8.0,
              ha="left", va="center", color=INK, linespacing=1.3)
    zoom.text(bx + .004, .850,
              f"+{inc_h:.2f}%\ndescent", fontsize=8.0,
              ha="left", va="center", color=INK, linespacing=1.3)

    OUT.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "main_frontier.pdf")
    fig.savefig(OUT / "main_frontier.png", dpi=300)
    plt.close(fig)
    print(CAPTION)


if __name__ == "__main__":
    main()
