#!/usr/bin/env python3
"""Regenerate publication figures from saved results; no optimization is run."""
from pathlib import Path
from fractions import Fraction
import argparse
import json

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
from matplotlib.ticker import LogLocator, NullFormatter
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BLUE, ORANGE, TEAL = '#2463A6', '#D07A27', '#148A7C'
INK, GRID = '#243042', '#DCE2E8'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 8.3,
    'axes.titlesize': 9.2, 'axes.labelsize': 8.3,
    'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'text.color': INK, 'axes.labelcolor': INK,
    'xtick.color': INK, 'ytick.color': INK,
    'axes.edgecolor': '#B9C2CC', 'axes.linewidth': .6,
    'mathtext.fontset': 'stix', 'pdf.fonttype': 42,
    'ps.fonttype': 42, 'savefig.facecolor': 'white',
})

def read(path):
    return json.loads(path.read_text())

def rational(value):
    return float(Fraction(str(value)))

def clean(ax, grid='x'):
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(length=3, width=.6)
    ax.tick_params(which='minor', length=0)
    ax.set_axisbelow(True)
    if grid:
        ax.grid(axis=grid, color=GRID, linewidth=.6)

def save(fig, directory, name):
    directory.mkdir(parents=True, exist_ok=True)
    fig.savefig(directory / f'{name}.pdf', bbox_inches=None)
    fig.savefig(directory / f'{name}.png', dpi=300, bbox_inches=None)
    plt.close(fig)

NAMES = ['two_scale', 'four_scale', 'spiked_six']
SPECTRA = [r'$(1,4)$', r'$(1,4,25,100)$', r'$(1,1,1,1,1,100)$']
TARGETS = ['0', '0.5', '0.9', '0.99', '0.9999', '0.99999999', '1']
TICKS = ['0', '0.5', '0.9', '0.99', r'$1-10^{-4}$', r'$1-10^{-8}$', '1']

def main_rows(retention):
    rows = [c for c in retention['cases'] if c['group'] == 'main']
    assert len(rows) == 21
    lookup = {(c['name'], str(c['alpha'])): c for c in rows}
    return [[lookup[n, a] for a in TARGETS] for n in NAMES]

def overview(variance, retention, out):
    fig = plt.figure(figsize=(7.05, 2.98))
    ax = fig.add_axes([.185, .235, .315, .625])
    cases = [c for c in variance['cases'] if c['r_fraction'] == .5]
    assert len(cases) == 6
    labels = [r'$(4,1);\ 0.1$', r'$(4,1);\ 0.5$',
              r'$(100,1^{\times5});\ 0.5$', r'$(10^{\times2},1^{\times3});\ 0.5$',
              r'$(25^{\times3},1^{\times2});\ 10$', r'$(2^{\times4},1^{\times4});\ 0.5$']
    for i, c in enumerate(cases):
        law = next(l for l in c['laws'] if l['kind'] == 'endpoint_mixture')
        values = [100 * law['metrics'][a]['loss'] / law['metrics'][a]['value'] for a in ['I','H']]
        assert min(values) > 0
        ax.plot(values, [i, i], color='#BDC7D2', lw=1.3, zorder=1)
        ax.scatter(values[0], i, color=BLUE, s=25, marker='o', zorder=3)
        ax.scatter(values[1], i, color=ORANGE, s=28, marker='D', zorder=3)
    ax.set_xscale('log')
    ax.set_xlim(.0009, 14)
    ax.set_xticks([.001,.01,.1,1,10], ['0.001','0.01','0.1','1','10'])
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_ylim(5.55, -.55)
    ax.set_yticks(range(6), labels)
    ax.tick_params(axis='y', length=0, pad=5)
    ax.set_xlabel('Gain improvement over mixture (%)')
    clean(ax)
    ax.tick_params(axis='y', length=0)
    ax.spines['left'].set_visible(False)
    ax.legend(handles=[Line2D([],[],marker='o',color=BLUE,linestyle='',label=r'Estimation $J_I$'),
                       Line2D([],[],marker='D',color=ORANGE,linestyle='',label=r'Descent $J_H$')],
              loc='lower left', bbox_to_anchor=(-.04,-.34), ncol=2, frameon=False,
              handletextpad=.3, columnspacing=.8, fontsize=8)
    fig.text(.025, .945, '(a) Same covariance, higher gains', fontsize=9.3, weight='bold')
    fig.text(.025, .873, r'Eigenvalues; $q$', fontsize=8, color='#5F6B7A')
    rows = main_rows(retention)
    vals = np.array([[rational(c['gap'])/rational(c['epsilon']) for c in row] for row in rows])
    assert np.min(vals) >= 0 and np.max(vals) <= 1
    axh = fig.add_axes([.58, .335, .395, .49])
    cmap = LinearSegmentedColormap.from_list('certificate', ['#F2F6FA','#BCD0E7',BLUE])
    im = axh.imshow(vals, vmin=0, vmax=1, cmap=cmap, aspect='auto')
    for i, row in enumerate(rows):
        for j, c in enumerate(row):
            v = vals[i,j]
            label = '0' if Fraction(c['gap']) == 0 else ('<0.01' if v < .01 else f'{v:.2f}')
            axh.text(j,i,label,ha='center',va='center',fontsize=8,
                     color='white' if v >= .58 else INK)
            if c['endpoint_shortcut']:
                axh.add_patch(Rectangle((j-.44,i-.42),.88,.84,fill=False,lw=.8,ec=BLUE))
    axh.set_xticks(range(7),['0','0.5','0.9','0.99','0.9999',r'$1-10^{-8}$','1'], fontsize=7.6)
    axh.set_yticks(range(3), ['2D','4D','6D'])
    axh.set_xlabel(r'Requested retention $\alpha$', labelpad=6)
    axh.tick_params(length=0)
    axh.set_xticks(np.arange(-.5,7,1),minor=True)
    axh.set_yticks(np.arange(-.5,3,1),minor=True)
    axh.grid(which='minor',color='white',lw=2)
    axh.tick_params(which='minor',bottom=False,left=False)
    for s in axh.spines.values(): s.set_visible(False)
    cbax=fig.add_axes([.68,.115,.25,.033])
    cb=fig.colorbar(im,cax=cbax,orientation='horizontal',ticks=[0,.5,1])
    cb.outline.set_visible(False)
    cb.ax.tick_params(length=2,labelsize=7.5)
    cb.set_label(r'Certificate width / $\epsilon$ (budget = 1)',fontsize=8,labelpad=2)
    fig.text(.565,.945,'(b) All 21 requests meet both guarantees',fontsize=9.0,weight='bold')
    save(fig,out,'experiment_overview')

def variance_sweep(variance,out):
    cases = sorted([c for c in variance['cases'] if c['name']=='spiked_six'],key=lambda c:c['r_fraction'])
    fig,axes=plt.subplots(2,3,figsize=(7.05,4.35),sharex=True,sharey='row')
    fig.subplots_adjust(left=.095,right=.98,bottom=.20,top=.89,wspace=.13,hspace=.22)
    for col,c in enumerate(cases):
        for row,a in enumerate(['I','H']):
            ax=axes[row,col]
            color=[BLUE,ORANGE][row]
            vs=[l['variance_R'] for l in c['laws']]
            x=np.geomspace(min(vs)*.8,max(vs)*1.3,100)
            baseline=c['baseline'][a]['value']
            lower=x*c['constants'][a+'_lower']/baseline
            upper=x*c['constants'][a+'_upper']/baseline
            ax.fill_between(x,lower,upper,color=color,alpha=.13)
            ax.plot(x,lower,color=color,lw=.7,alpha=.5)
            ax.plot(x,upper,color=color,lw=.7,alpha=.5)
            for l in c['laws']:
                endpoint=l['kind']=='endpoint_mixture'
                ax.scatter(l['variance_R'],l['metrics'][a]['relative_loss'],
                           marker='D' if endpoint else 'o',s=30 if endpoint else 17,
                           c=color,edgecolors='white',linewidths=.4,zorder=3)
            ax.set_xscale('log'); ax.set_yscale('log')
            ax.set_xlim(3e-6,.4); ax.set_ylim(1e-7,1)
            ax.set_xticks([1e-5,1e-3,1e-1])
            ax.set_yticks([1e-6,1e-4,1e-2,1])
            clean(ax,grid='both')
            if row==0:
                frac={.25:'1/4',.5:'1/2',.75:'3/4'}[c['r_fraction']]
                ax.set_title(r'$\vartheta='+frac+r'$, $r='+f'{c["r"]:.3f}'+r'$',pad=8)
            else:ax.set_xlabel(r'Block-energy variance $\operatorname{Var}(R)$')
            if col==0:ax.set_ylabel(('Estimation' if a=='I' else 'Descent')+' relative loss')
    fig.legend(handles=[Line2D([],[],marker='o',color=INK,linestyle='',label='Symmetric two-point energy'),
                       Line2D([],[],marker='D',color=INK,linestyle='',label='Endpoint-energy mixture'),
                       Patch(facecolor='#C7D7E7',label='Analytic variance bounds')],
               loc='lower center',bbox_to_anchor=(.52,.025),ncol=3,frameon=False,
               fontsize=8,columnspacing=1.1,handletextpad=.45)
    save(fig,out,'same_covariance_variance')

def retention_intervals(retention,out):
    rows=main_rows(retention)
    fig,axes=plt.subplots(3,1,figsize=(7.05,4.7),sharex=True)
    fig.subplots_adjust(left=.105,right=.97,bottom=.15,top=.925,hspace=.33)
    for ax,row,color,spec in zip(axes,rows,[BLUE,TEAL,ORANGE],SPECTRA):
        for j,c in enumerate(row):
            scale=c['unconstrained_JH_numerical']
            lo,hi=rational(c['JH'])/scale,rational(c['V_upper'])/scale
            assert hi >= lo-1e-12
            ax.plot([j,j],[lo,hi],color=color,lw=2,zorder=2)
            ax.plot([j-.07,j+.07],[hi,hi],color=color,lw=1.2)
            ax.plot(j,lo,marker='o',ms=4.5,mec=color,mfc='white' if c['endpoint_shortcut'] else color,zorder=3)
        endpoint=rational(row[-1]['JH'])/row[-1]['unconstrained_JH_numerical']
        ax.axhline(endpoint,color='#8B98A6',ls=(0,(3,3)),lw=.7)
        ax.set_ylim(.45,1.04);ax.set_yticks([.5,.75,1])
        ax.set_xlim(-.35,6.35)
        ax.set_title(spec,loc='left',color=color,pad=3)
        clean(ax,grid='y')
    axes[-1].set_xticks(range(7),TICKS)
    axes[-1].set_xlabel(r'Requested retention $\alpha$ (discrete requests)')
    fig.text(.025,.56,r'Descent guarantee / $J_H^\star$',rotation=90,ha='center',va='center')
    fig.legend(handles=[Line2D([],[],marker='o',color=INK,linestyle='',label='Implemented lower bound'),
                       Line2D([],[],marker='_',color=INK,linestyle='',label='Certified upper bound'),
                       Line2D([],[],marker='o',mfc='white',color=INK,linestyle='',label='Endpoint shortcut')],
               loc='upper center',bbox_to_anchor=(.54,1.01),ncol=3,frameon=False,fontsize=8,
               columnspacing=1.1,handletextpad=.4)
    save(fig,out,'retention_interface')

def ogd_convergence(ogd,out):
    fig,axes=plt.subplots(1,3,figsize=(7.05,2.8),sharex=True,sharey=True)
    fig.subplots_adjust(left=.09,right=.98,bottom=.31,top=.88,wspace=.15)
    for ax,name,spec in zip(axes,['two_scales','four_scales','spiked_six'],SPECTRA):
        for run in [r for r in ogd['runs'] if r['name']==name]:
            chk=run['checkpoints']; x=[c['T'] for c in chk]
            fixed=run['schedule']=='theorem'; grouped='equal_h_groups' in run
            color,marker=(BLUE,'o') if fixed else ((TEAL,'s') if grouped else (ORANGE,'D'))
            ax.plot(x,[c['primal_dual_gap'] for c in chk],color=color,marker=marker,ms=3.8,lw=1.3)
            if fixed:
                ax.plot(x,[c['theorem_decoder_gap_bound'] for c in chk],color='#7C8794',ls=(0,(4,2)),lw=1.1)
        ax.set_xscale('log',base=2);ax.set_yscale('log')
        ax.set_xticks([64,256,1024,4096],['64','256','1024','4096'])
        ax.tick_params(axis='x',labelsize=7.5)
        ax.set_ylim(1e-4,1e3)
        ax.set_yticks([1e-4,1e-2,1,100])
        ax.set_xlabel('OGD iterations');ax.set_title(spec,pad=8)
        clean(ax,grid='y')
    axes[0].set_ylabel('Weighted-objective gap')
    handles=[Line2D([],[],color=BLUE,marker='o',ms=3.8,label='Fixed step'),
             Line2D([],[],color=ORANGE,marker='D',ms=3.8,label='AdaGrad'),
             Line2D([],[],color=TEAL,marker='s',ms=3.8,label='AdaGrad + symmetry'),
             Line2D([],[],color='#7C8794',ls='--',label='Fixed-step bound')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.54,.025),ncol=4,
               frameon=False,fontsize=8,columnspacing=1.1,handlelength=1.8)
    save(fig,out,'ogd_convergence')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data-root',type=Path,default=ROOT/'data')
    ap.add_argument('--output',type=Path,default=ROOT/'figures')
    args=ap.parse_args()
    variance=read(args.data_root/'numerics/same_covariance_variance.json')
    retention=read(args.data_root/'retention/results/retention_validation.json')
    ogd=read(args.data_root/'numerics/ogd/ogd_results.json')
    overview(variance,retention,args.output)
    variance_sweep(variance,args.output)
    retention_intervals(retention,args.output)
    ogd_convergence(ogd,args.output)
    print('Saved four PDF/PNG figure pairs from existing result files.')

if __name__=='__main__':main()
