# Directional Probing

Code for the estimation--descent tradeoff from noisy directional measurements.
Python 3.12 is recommended. Install the numerical and plotting dependencies:

```bash
python -m pip install -r requirements.txt
```

Run all commands from the repository root. Results and figures are generated
locally; no precomputed outputs are included.

## Solve a design problem

```bash
python data/retention/code/retention_solver.py --h 1 4 --q 0.5 --alpha 0.99 --epsilon 0.0001 --output result.json
python data/retention/code/exact_certificate.py result.json
```

`h` contains curvature eigenvalues, `q` is relative noise variance, `alpha`
is retained estimation gain, and `epsilon` is absolute descent-gain tolerance.
The output includes a finite probing distribution, both response rules, and
an exact feasibility and optimality certificate. The practical solver uses
exchange; `finite_reference.py` implements the conservative rational reference.

## Reproduce experiments and figures

```bash
python data/numerics/run_all.py
python data/numerics/frontier_plot.py
python data/retention/code/retention_solver.py --validation-suite data/retention/results
python data/retention/code/verify_bundle.py
python code/plot_experiments.py
python code/plot_frontier.py
```

The full runs can be computationally expensive. For a shorter structural
experiment, use `python data/numerics/run_all.py --quick`.
The figure scripts read the generated results and write to `figures/`.

## Exact checks

These checks use only the Python standard library:

```bash
python data/verification/verify_rational_balancing.py
python data/retention/code/test_exact_certificate.py
python data/retention/code/finite_reference.py --mode self-test
```

Dependencies are installed separately and retain their respective licenses.
